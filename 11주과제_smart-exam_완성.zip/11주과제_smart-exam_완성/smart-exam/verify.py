"""3단계: questions.js 검증 (일회용). 사용법: python verify.py questions.js"""
import json, re, sys

path = sys.argv[1] if len(sys.argv) > 1 else 'questions.js'
src = open(path, encoding='utf-8').read()
m = re.search(r'window\.QUESTIONS\s*=\s*(\[.*\])\s*;?\s*$', src, re.S)
qs = json.loads(m.group(1))
errors = []

choice = [q for q in qs if q.get('type') == 'choice']
short = [q for q in qs if q.get('type') == 'short']
if (len(qs), len(choice), len(short)) != (220, 200, 20):
    errors.append(f'1. 문제 수: 전체 {len(qs)}, 객관식 {len(choice)}, 단답형 {len(short)}')

ids = [q.get('id') for q in qs]
expected = [f'G-{i:03d}' for i in range(1, 101)] + [f'C-{i:03d}' for i in range(1, 101)] + [f'S-{i:03d}' for i in range(1, 21)]
dups = sorted({i for i in ids if ids.count(i) > 1})
if dups: errors.append(f'2. id 중복: {dups}')
missing = sorted(set(expected) - set(ids)); extra = sorted(set(ids) - set(expected))
if missing: errors.append(f'2. id 누락: {missing}')
if extra: errors.append(f'2. 예상 밖 id: {extra}')

for q in choice:
    o = q.get('options')
    if not isinstance(o, list) or len(o) != 4 or any(not str(x).strip() for x in o):
        errors.append(f'3. 보기 오류: {q["id"]}')
    if q.get('answer') not in (1, 2, 3, 4):
        errors.append(f'4. 정답 번호 오류: {q["id"]} -> {q.get("answer")}')
for q in short:
    if not str(q.get('answer', '')).strip() or not q.get('accepted'):
        errors.append(f'5. 단답형 정답/accepted 누락: {q["id"]}')

junk = re.compile(r'Page|예상문제집|\[제\s*\d+\s*영역\]|^\s*\d+\s*/\s*\d+\s*$')
for q in qs:
    for t in [q.get('question', '')] + list(q.get('options') or []):
        if junk.search(str(t)):
            errors.append(f'7. 잔여 문구: {q["id"]}: {str(t)[:40]}')

# 6. 정답표 대조: answer_key.json ({"G-001":2, ..., "S-001":"3년"})이 있으면 비교
try:
    key = json.load(open('answer_key.json', encoding='utf-8'))
    for q in qs:
        if q['id'] in key and str(key[q['id']]) != str(q['answer']):
            errors.append(f'6. 정답 불일치: {q["id"]} 데이터={q["answer"]} 정답표={key[q["id"]]}')
except FileNotFoundError:
    print('6. answer_key.json 없음 - 정답표 대조 생략')

print(f'전체 {len(qs)} / 객관식 {len(choice)} / 단답형 {len(short)}')
print('검증 통과' if not errors else '\n'.join(errors))
sys.exit(1 if errors else 0)
