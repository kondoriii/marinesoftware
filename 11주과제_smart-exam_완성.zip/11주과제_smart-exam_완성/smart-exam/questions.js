window.QUESTIONS = [
 {
  "id": "G-001",
  "type": "choice",
  "question": "스마트공장 수준확인 제도에서 '수준확인서'라는 명칭을 사용하는 이유로 가장 적절한 것은?",
  "options": [
   "중소벤처기업부 장관의 직인이 생략되기 때문",
   "인정기관(KAB,KOLAS 등)에서 승인한 인증기관이 아니기 때문",
   "1년마다 갱신해야 하는 임시 문서이기 때문",
   "자가진단 결과만으로 발급되는 서류이기 때문"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-002",
  "type": "choice",
  "question": "스마트공장 수준확인 사업의 추진체계 중 '확인기관'과 '교육·심의기관'을 선정하고 심사원 인력 풀(Pool)을 총괄 관리하는 기관은?",
  "options": [
   "중소벤처기업부 (총괄기관)",
   "스마트제조혁신추진단 (추진기관)",
   "한국표준협회 (확인기관)",
   "기술보증기금 (금융기관)"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-003",
  "type": "choice",
  "question": "스마트공장 수준확인 사업에서 '구축시스템 스마트화 수준'은 크게 몇 단계로 구분되는가?",
  "options": [
   "3단계 (기초,중간,고도)",
   "4단계 (Level 1 ~ Level 4)",
   "5단계 (ICT미적용,기초,중간1,중간2,고도)",
   "6단계 (Level 0 ~ Level 5)"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-004",
  "type": "choice",
  "question": "다음 중 '기업제조혁신역량 수준'의 단계 구분으로 옳은 것은?",
  "options": [
   "Level 0 ~ Level 5 (6단계)",
   "Level 1 ~ Level 5 (5단계)",
   "기초 ~ 고도 (4단계)",
   "미인식 ~ 자율화 (3단계)"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-005",
  "type": "choice",
  "question": "스마트공장 수준확인 사업의 지원 대상에 해당하지 않는 기업은?",
  "options": [
   "자체 역량으로 스마트공장을 구축한 중소·중견 제조기업",
   "정부 스마트공장 사업 참여 이력이 있으나 자발적 고도화를 추진해 수준 상승이 기대되는 기업",
   "스마트공장 수준확인서 유효기간이 만료된 기업",
   "현재 정부 스마트공장 구축사업에 참여 중인 기업"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-006",
  "type": "choice",
  "question": "수준확인 신청 시 제출하는 '국세 및 지방세 납세 증명서'의 유효기간 기준은?",
  "options": [
   "발행일로부터 1개월 이내",
   "발행일로부터 3개월 이내",
   "발행일로부터 6개월 이내",
   "발행일로부터 1년 이내"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-007",
  "type": "choice",
  "question": "확인기관이 지원기업 선정 통보일로부터 심사원을 배정해야 하는 기한은?",
  "options": [
   "3일 이내",
   "5일 이내",
   "7일 이내",
   "14일 이내"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-008",
  "type": "choice",
  "question": "심사원이 수준확인 현장 심사를 수행할 때 준수해야 할 원칙으로 옳지 않은 것은?",
  "options": [
   "기업을 직접 방문하여 수준확인을 수행하는 것이 원칙이다.",
   "동일한 날에 2개 이상의 지원기업에 대해 수준확인을 수행할 수 없다.",
   "심사일로부터 14일 이내에 심사보고서와 수준 평가표를 확인기관에 제출해야 한다.",
   "1공장과 2공장이 동일 제품을 생산하면 1공장만 방문하여 일괄 평가한다."
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-009",
  "type": "choice",
  "question": "확인기관은 기업의 신청일로부터 며칠 이내에 심사 완료를 위해 노력하여야 하는가?",
  "options": [
   "14일 이내",
   "21일 이내",
   "30일 이내",
   "60일 이내"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-010",
  "type": "choice",
  "question": "교육·심의기관이 운영하는 '심의위원회'의 구성 기준으로 옳은 것은?",
  "options": [
   "최소 3인 이상 구성,외부 심의위원 1인 이상 필수",
   "최소 5인 이상 구성,외부 심의위원 2인 이상 필수",
   "최소 7인 이상 구성,외부 심의위원 3인 이상 필수",
   "최소 10인 이상 구성,외부 심의위원 5인 이상 필수"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-011",
  "type": "choice",
  "question": "심의위원회로부터 지원과제에 대해 몇 회 이상 보완 요청을 받은 경우, 심의가 종료되고 심사원 자격이 박탈되는가?",
  "options": [
   "2회 이상",
   "3회 이상",
   "4회 이상",
   "5회 이상"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-012",
  "type": "choice",
  "question": "심사보고서 보완이 필요한 경우, 심사결과 통보일로부터 며칠 이내에 보완 제출해야 하는가?",
  "options": [
   "3일 이내",
   "5일 이내",
   "7일 이내 (필요시 7일 연장 가능)",
   "14일 이내"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-013",
  "type": "choice",
  "question": "스마트공장 수준확인서의 유효기간과 시작일 기준으로 옳은 것은?",
  "options": [
   "발급일로부터 1년 (신청일 기준)",
   "발급일로부터 2년 (현장심사일 기준)",
   "발급일로부터 3년 (심사 심의일 기준)",
   "발급일로부터 5년 (발급일 기준)"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-014",
  "type": "choice",
  "question": "지원기업이 수준등급 결과에 대해 이의신청을 할 수 있는 기한과 횟수는?",
  "options": [
   "확인서 발급일로부터 7일 이내,1회",
   "확인서 발급일로부터 10일 이내,1회",
   "확인서 발급일로부터 14일 이내,2회",
   "확인서 발급일로부터 30일 이내,제한 없음"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-015",
  "type": "choice",
  "question": "다음 중 심사원이 스스로 해당 업무 수행을 '회피'해야 하는 사유에 해당하지 않는 것은?",
  "options": [
   "수준확인 대상 과제의 도입기업·공급기업에 소속한 경우",
   "과제의 총괄책임자와 민법 제777조에 따른 친족관계(8촌 이내 혈족,4촌 이내 인척,배우자)인 경우",
   "과거 해당 기업과 전혀 무관한 타 업종 심사 경험이 있는 경우",
   "평가의 공정성,객관성을 해할 우려가 있다고 판단되는 경우"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-016",
  "type": "choice",
  "question": "수준확인 심사원 풀(Pool)에서 제외된 심사원이 자격을 회복하기 위한 절차는?",
  "options": [
   "1년 경과 후 자동 회복",
   "교육·심의기관에서 시행하는 보수 교육 이수",
   "확인기관장의 추천서 제출",
   "신규 심사원 시험 재응시 면제"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-017",
  "type": "choice",
  "question": "다음 중 나라장터 공공입찰(경쟁입찰) 신인도 평가 시 스마트공장 수준확인 기업에 부여되는 가점은?",
  "options": [
   "기초(1.0점),중간1~2(2.0점),고도(3.0점)",
   "기초(0.5점),중간1~2(1.0점),고도(2.0점)",
   "기초(1.0점),중간1~2(1.5점),고도(2.0점)",
   "수준과 무관하게 일괄 2.0점"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-018",
  "type": "choice",
  "question": "수준확인서 보유기업에 대한 금융 인센티브 중 기술보증기금의 우대보증 비율은?",
  "options": [
   "70~80%",
   "80~85%",
   "85~90%",
   "90~100%"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-019",
  "type": "choice",
  "question": "스마트공장 수준확인 투입공수(MD) 배정 기준으로 옳은 것은?",
  "options": [
   "모든 기업에 일괄 1MD 배정",
   "기초 1MD,중간1은 2MD,중간2 이상은 4MD 배정",
   "기초 2MD,중간1은 3MD,중간2 이상은 5MD 배정",
   "기업 규모와 무관하게 심사원이 임의로 결정"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-020",
  "type": "choice",
  "question": "현장 방문 시 중간수준으로 알고 방문했으나 실제로는 기초수준인 경우, 심사원의 올바른 조치 방법은?",
  "options": [
   "임의로 중간수준으로 상향 평가하여 보고서를 작성한다.",
   "심사를 즉시 중단하고 철수한다.",
   "확인기관과 협의하여 1MD로 마무리한다.",
   "기업에 추가 비용을 청구하여 4MD로 진행한다."
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-021",
  "type": "choice",
  "question": "스마트공장 수준 자가진단표에서 '기초' 수준을 판단하는 주요 특징으로 옳은 것은?",
  "options": [
   "모든 설비가 AI 기반 디지털 트윈으로 자율 운영됨",
   "정보시스템을 활용하여 기준정보 및 생산실적,매입/매출을 관리함",
   "정보시스템이 전혀 없어 모든 데이터를 수기(엑셀)로 관리함",
   "2개 이상 공정 설비-시스템이 실시간 모니터링됨"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-022",
  "type": "choice",
  "question": "다음 중 2026년 스마트공장 보급확산 사업 중 '스마트공장 수준확인'의 지원비율(%)은?",
  "options": [
   "50%",
   "75%",
   "80%",
   "100%"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-023",
  "type": "choice",
  "question": "수준확인 심의제도의 궁극적인 목적으로 가장 적절한 것은?",
  "options": [
   "심사원의 수당을 삭감하기 위함",
   "수준확인 보고서의 상향 평준화와 균질성 확보를 통해 수요기업의 제조경쟁력 향상에 기여",
   "불합격 기업을 시장에서 퇴출시키기 위함",
   "확인기관의 행정 업무를 줄이기 위함"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-024",
  "type": "choice",
  "question": "다음 중 스마트공장 수준확인 지원 제외 대상에 해당하지 않는 기업은?",
  "options": [
   "휴·폐업 중인 기업",
   "국세 및 지방세 체납 중인 기업",
   "유흥·향락업,숙박·음식점",
   "자체 구축한 스마트공장 운영이 완료된 제조기업"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-025",
  "type": "choice",
  "question": "해외 공장 등 물리적 방문이 불가능한 경우의 심사 진행 원칙으로 옳은 것은?",
  "options": [
   "어떠한 경우에도 심사를 진행할 수 없다.",
   "방문 불가 사유를 명시하고 현장 사진 등 증적 자료를 협조받아 진행 가능하다.",
   "기업의 구두 설명만으로 증적 없이 평가한다.",
   "국내 본사 사무실만 보고 현장과 동일하다고 간주한다."
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-026",
  "type": "choice",
  "question": "마이클 포터의 가치사슬(Value Chain) 모델에서 '본원적 활동(Primary Activity)'에 해당하지 않는 것은?",
  "options": [
   "내부 물류 (Inbound Logistics)",
   "제조,생산 (Operations)",
   "인적 자원 관리 (Human Resource Management)",
   "마케팅,영업 (Marketing & Sales)"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-027",
  "type": "choice",
  "question": "KS X 9001-3 스마트공장 진단평가 모델에서 제시하는 '6대 핵심 가치사슬(프로세스)' 영역에 해당하지 않는 것은?",
  "options": [
   "제품개발,생산계획",
   "공정관리,품질관리",
   "설비관리,물류운영",
   "재무회계,인사관리"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-028",
  "type": "choice",
  "question": "KSA의 스마트공장 역량평가 모델은 총 몇 개의 영역으로 구성되어 있는가?",
  "options": [
   "6개 영역",
   "8개 영역",
   "10개 영역 ([01]리더십과 전략 ~ [10]성과)",
   "12개 영역"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-029",
  "type": "choice",
  "question": "KS X 9001-3-1:2025의 스마트공장 성숙도 모델(Level 0 ~ Level 5)에서 'Level 3'의 특성과 정의로 옳은 것은?",
  "options": [
   "미인식 또는 미식별 - 수기로 실적 관리",
   "측정 및 확인 - 실시간 추적 및 외부 모니터링 시스템 연결",
   "분석 및 제어 - 수집된 정보를 분석하고 이상 유무 판단 후 제어 가능",
   "맞춤 및 자율 - 사람의 관여를 최소화한 자율 운영"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-030",
  "type": "choice",
  "question": "다음 생산방식 중 대다수 중소기업이 채택하며, 설비 가동률은 높으나 리드타임이 길어지고 로트 불량 발생 위험이 있는 방식은?",
  "options": [
   "연속생산방식",
   "반복생산방식",
   "로트(Lot) 생산방식",
   "개별생산방식"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-031",
  "type": "choice",
  "question": "수요 형태에 따른 제조환경 중 다품종 소량의 제품을 주문받아 가공하며, BOM의 신속한 개발과 납기 준수가 중요한 형태는?",
  "options": [
   "MTS (계획생산)",
   "ATO (주문조립생산)",
   "MTO (주문가공생산)",
   "ETO (설계생산)"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-032",
  "type": "choice",
  "question": "제조활동의 성과지표(KPI)를 평가할 때 전통적인 QCD 영역에 최근 추가되어 중요시되는 2가지 영역은?",
  "options": [
   "생산성(P),원가(C)",
   "안전(S),환경(E)",
   "납기(D),유연성(F)",
   "매출(R),이익(P)"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-033",
  "type": "choice",
  "question": "제품 설계와 개발 단계에서 제품 원가의 약 몇 %가 결정되는가?",
  "options": [
   "20%",
   "50%",
   "80%",
   "95%"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-034",
  "type": "choice",
  "question": "효율적 생산계획 수립을 위한 기준정보(Meta Data)에 해당하지 않는 것은?",
  "options": [
   "자재 명세서(BOM)",
   "표준가공순서(Routing) 및 표준시간",
   "일일 작업자의 출퇴근 기록",
   "품목 코드 및 공정 코드"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-035",
  "type": "choice",
  "question": "자재소요량계획(MRP)과 능력자원분배계획(CRP)에 대한 설명으로 옳은 것은?",
  "options": [
   "CRP는 소요자재의 수배를,MRP는 부하와 능력의 비교를 수행한다.",
   "MRP 수행에 앞서 CRP를 먼저 수행하는 것은 불가능하다.",
   "BOM(자재명세서)은 MRP에서 자재소요량 산출의 근간으로 활용된다.",
   "부하계획은 설비의 보유능력을 무시하고 최대치로 배정하는 것이다."
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-036",
  "type": "choice",
  "question": "공정관리의 기능 중 '작업배정(Dispatching)'과 '진도관리(Expediting)'에 대한 설명으로 옳은 것은?",
  "options": [
   "작업배정은 진행 중인 작업의 진척도를 수량적으로 관리하는 것이다.",
   "진도관리는 작업현장에 작업 지시를 내리고 자재를 인계하는 것이다.",
   "여력관리는 예정 투입량과 실제 투입량을 비교하는 투입산출관리이다.",
   "절차계획은 작업자의 급여를 산정하는 절차이다."
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-037",
  "type": "choice",
  "question": "공정이상 발생 시 대응 프로세스에서 만성적 공정문제를 해결하기 위해 인과관계를 분석하고 통계적 기법(가설검정, 분산분석 등)을 활용하여 찾아내는 핵심 원인 인자는?",
  "options": [
   "Red-X",
   "Green-Y",
   "Black-Belt",
   "Blue-Z"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-038",
  "type": "choice",
  "question": "품질의 가치사슬 단계에서 '원류단계(설계 측면)'의 품질비용이 1단위라면, '사후관리(고객 클레임)' 단계의 품질비용은 약 몇 단위가 발생하는가?",
  "options": [
   "2단위",
   "10단위",
   "50단위",
   "100단위"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-039",
  "type": "choice",
  "question": "계측장비의 정확성, 정밀성, 안정성, 선형성 등을 보장하여 품질기록의 신뢰성을 확보하기 위한 측정시스템 분석 기법은?",
  "options": [
   "FMEA",
   "MSA",
   "QFD",
   "DOE"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-040",
  "type": "choice",
  "question": "설비관리 프로세스에서 사용부서(제조부문)가 설비를 이해하고 일상점검, 급유, 청소 등을 수행하는 보전 활동은?",
  "options": [
   "사후보전 (BM)",
   "자주보전 (일상보전)",
   "개량보전 (CM)",
   "긴급보전 (EBM)"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-041",
  "type": "choice",
  "question": "물류운영 프로세스에서 원재료 조달부터 최종 소비자에게 전달되는 전체 영역을 무엇이라 하는가?",
  "options": [
   "협의의 물류",
   "광의의 물류",
   "사내 물류",
   "역방향 물류"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-042",
  "type": "choice",
  "question": "기업제조혁신역량 수준 평가 시트에서 '표준화'의 의미를 가장 정확하게 나타낸 수식은?",
  "options": [
   "표준화 = 표준서 × 교육",
   "표준화 = 표준서 × 실행",
   "표준화 = 표준서 × 승인",
   "표준화 = 표준서 × 시스템"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-043",
  "type": "choice",
  "question": "'부분적 표준화'와 '전사적 표준화'의 차이점에 대한 설명으로 옳은 것은?",
  "options": [
   "부분적 표준화는 대표 제품이 모든 관리영역에서 통합 적용되는 것이다.",
   "전사적 표준화는 일부 공정이나 부서에만 한정 적용되는 것이다.",
   "표준서는 있으나 실행 기록이 없다면 표준화가 전혀 되지 않은 것이다.",
   "전사적 표준화는 외부 협력사까지 모두 동일한 표준을 쓰는 것이다."
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-044",
  "type": "choice",
  "question": "기업제조혁신역량 수준평가에서 '[01]리더십과 전략 > 성과지표 관리'와 '[10]성과 > PQCDSE 성과지표'의 차이점은?",
  "options": [
   "두 항목은 완전히 동일한 증적을 제출해야 한다.",
   "리더십과 전략은 관리주체·수집/분석 프로세스 등 관리역량을 보고,성과는 연도별 실적·트렌드를 본다.",
   "성과 영역은 정성적 평가만 수행한다.",
   "리더십과 전략 영역은 최고경영자와 무관하다."
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-045",
  "type": "choice",
  "question": "KS X 9001의 구성 중 수준확인 심사원이 주로 참고해야 하는 '스마트공장 진단평가모델(운영관리시스템)'은 몇 부에 해당하는가?",
  "options": [
   "KS X 9001-1",
   "KS X 9001-2",
   "KS X 9001-3",
   "KS X 9001-4"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-046",
  "type": "choice",
  "question": "다음 자동화 용어 중 '시각이나 청각과 관련지어진 인간의 아날로그적 인지 세계와 기계의 디지털 세계를 연결하는 인터페이스'는?",
  "options": [
   "PLC",
   "HMI",
   "SCADA",
   "FMS"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-047",
  "type": "choice",
  "question": "서로 다른 기종이나 제조사의 산업용 장치들끼리 실시간으로 통신하고 상호운용성을 확보하기 위한 개방형 산업용 통신 프로토콜은?",
  "options": [
   "OPC-UA",
   "RS-232",
   "HDMI",
   "USB"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-048",
  "type": "choice",
  "question": "기존 '자동화공장'과 '스마트공장'의 비교로 옳지 않은 것은?",
  "options": [
   "자동화공장은 사람과 분리된 작업환경이지만,스마트공장은 사람과 공동작업이 가능하다.",
   "자동화공장은 사후보전 중심이지만,스마트공장은 예측보전 중심이다.",
   "자동화공장은 다품종 대량생산에 특화되어 있고,스마트공장은 소품종 대량생산에 특화되어 있다.",
   "자동화공장은 HW 중시,스마트공장은 SW와 Data를 중시한다."
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-049",
  "type": "choice",
  "question": "생산과 품질, 안전에 필요한 부분만 값싸고 빠르게 자동화하는 간이자동화를 뜻하는 용어는?",
  "options": [
   "LCA (Low Cost Automation)",
   "FMS (Flexible Manufacturing System)",
   "CPS (Cyber Physical System)",
   "RPA (Robotic Process Automation)"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-050",
  "type": "choice",
  "question": "계측제어시스템(SCADA/PLC)의 기본 구조 3요소에 해당하지 않는 것은?",
  "options": [
   "제어부 (PLC/DCS)",
   "검출부 (Sensor)",
   "조작부 (Actuator)",
   "결재부 (Approval)"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-051",
  "type": "choice",
  "question": "분산제어시스템(DCS)과 프로그램가능로직제어기(PLC)의 비교 중 옳은 것은?",
  "options": [
   "DCS는 논리 중심의 고속 처리,PLC는 수학계산 중심의 저속 처리를 한다.",
   "DCS는 주로 Analog 연속신호(4~20mA)를,PLC는 On/Off 접점신호나 Pulse를 처리한다.",
   "PLC는 타 Maker 장비 간의 결합 유연성이 매우 떨어진다.",
   "DCS는 Relay Panel을,PLC는 Analog Panel을 대체하기 위해 등장했다."
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-052",
  "type": "choice",
  "question": "설비 유지보수 자동화를 위한 예지진단 4대 센싱 기술 중 가장 빠른 시점(약 3개월 이전)에 이상을 감지할 수 있는 기술은?",
  "options": [
   "진동분석",
   "오일분석",
   "소리분석",
   "열화상분석"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-053",
  "type": "choice",
  "question": "물류 자동화 로봇 중 정해진 가이드(마그네틱 테이프 등) 없이 주변 환경을 스스로 인식하고 경로를 설정하여 작업하는 지능형 로봇은?",
  "options": [
   "AGV (Automated Guided Vehicle)",
   "AMR (Autonomous Mobile Robot)",
   "스태커 크레인 (Stacker Crane)",
   "갠트리 로봇"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-054",
  "type": "choice",
  "question": "정해진 주기에 다수의 고객사 정보시스템에 자동 접속하여 주문정보를 수집하고 단순 반복적 사무작업을 자동 처리하는 소프트웨어 로봇 기술은?",
  "options": [
   "RPA (Robotic Process Automation)",
   "Cobot (협동로봇)",
   "Drone",
   "RFID"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-055",
  "type": "choice",
  "question": "클라우드 컴퓨팅의 3가지 서비스 유형 중 운영체제, 데이터베이스 등 애플리케이션 개발 및 실행을 위한 '플랫폼'을 제공하는 형태는?",
  "options": [
   "IaaS (Infrastructure as a Service)",
   "PaaS (Platform as a Service)",
   "SaaS (Software as a Service)",
   "DaaS (Data as a Service)"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-056",
  "type": "choice",
  "question": "검사 자동화에서 제품의 제조일자를 판독하는 기술과 제조일자의 유무를 검증하는 기술의 짝으로 옳은 것은?",
  "options": [
   "OCR 검사 - 제조일자 유무 검사",
   "바코드 검사 - 치수 검사",
   "비파괴 검사 - 관능 검사",
   "샘플링 검사 - 전수 검사"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-057",
  "type": "choice",
  "question": "설비 정보 네트워크의 유선 통신 방식 중 '광섬유 통신'의 장점으로 가장 거리가 먼 것은?",
  "options": [
   "높은 대역폭",
   "긴 통신 거리",
   "뛰어난 전자파 간섭 저항성",
   "매우 저렴한 초기 설치 및 유지비용"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-058",
  "type": "choice",
  "question": "무선 통신 기술 중 저전력 광역 무선 통신 기술로 넓은 커버리지와 배터리 구동 센서 네트워크(장거리 데이터 전송)에 적합한 것은?",
  "options": [
   "Bluetooth",
   "LoRaWAN",
   "Wi-Fi",
   "RFID"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-059",
  "type": "choice",
  "question": "IoT 환경에서 경량 메시지 프로토콜로 사용되며, 불안정한 네트워크 환경에서도 대량의 센서 데이터를 효율적으로 전송하는 데 효과적인 프로토콜은?",
  "options": [
   "MQTT",
   "Modbus",
   "Ethernet/IP",
   "Profibus"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-060",
  "type": "choice",
  "question": "제조현장의 다양한 설비와 통신 규약 혼재 문제를 해결하고, 물리적 자산을 디지털 형태로 표준화하여 표현하기 위해 등장한 국제표준은?",
  "options": [
   "AAS (Asset Administration Shell)",
   "ERP (Enterprise Resource Planning)",
   "MRP (Material Requirements Planning)",
   "QFD (Quality Function Deployment)"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-061",
  "type": "choice",
  "question": "공장에너지관리시스템(FEMS)에 대한 설명으로 옳은 것은?",
  "options": [
   "오직 전기 에너지 사용량만 측정하며 화석연료는 제외한다.",
   "EMS(에너지관리정보시스템)와 MES(생산관리시스템)를 통합한 것이다.",
   "설비의 전류/전압 변화 모니터링을 통해서는 설비 고장을 예측할 수 없다.",
   "HW 요소는 포함되지 않고 오직 SW로만 구성된다."
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-062",
  "type": "choice",
  "question": "다음 중 안전사고 예방을 위한 스마트공장 자동화 사례로 적절하지 않은 것은?",
  "options": [
   "협동로봇의 자동 비상 정지 및 인터록(Interlock) 시스템",
   "작업자 안전지킴이 스마트 웨어러블 기기",
   "센서 기반 자동 화재 억제 시스템",
   "위험 구역 내 안전펜스 및 비상정지 스위치 전면 철거"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-063",
  "type": "choice",
  "question": "단위설비 자동화보다 MES 등 기간 정보시스템과 통합된 자동화가 필요한 이유로 가장 적절한 것은?",
  "options": [
   "현장에서 수동제어에 의존한 고성능 설비는 잘못된 방향으로 더 빨리 달리는 결과(대량 불량)를 초래할 수 있기 때문",
   "단위설비 자동화 비용이 정보시스템 구축 비용보다 항상 저렴하기 때문",
   "정보시스템과 연계하면 설비의 물리적 수명이 영구적으로 늘어나기 때문",
   "정부 지원사업에서 단위설비 도입을 법적으로 금지하고 있기 때문"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-064",
  "type": "choice",
  "question": "자동화 설비로부터 수집하는 가공데이터 중 '전류/전압, 온도, 습도, 속도, 진동, 압력' 등에 해당하는 데이터는?",
  "options": [
   "결과계 데이터",
   "원인계 데이터",
   "재무 데이터",
   "회계 데이터"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-065",
  "type": "choice",
  "question": "자동화 설비 보급 확산에 따른 설비관리 측면의 위험요소(부정적 면)에 대한 대응방안으로 옳지 않은 것은?",
  "options": [
   "작업자의 일상적 자주보전활동 수행",
   "고효율 설비 대체를 통한 에너지 절감",
   "ICT 기반 점검 데이터 획득 및 CMMS 활용 예지보전활동",
   "설비 고장은 불가피한 자연현상이므로 사후보전만 고수"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-066",
  "type": "choice",
  "question": "회사의 경영 Vision 및 전략을 바탕으로 IT의 Vision과 실행계획을 수립하여 '붕어빵 시스템' 도입을 방지하는 사전 계획 수립 활동은?",
  "options": [
   "ISP (정보화전략계획)",
   "BPR (업무프로세스재설계)",
   "ERP (전사적자원관리)",
   "SCM (공급망관리)"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-067",
  "type": "choice",
  "question": "다음 제조기업 가치사슬 영역과 주요 정보시스템의 매핑이 잘못된 것은?",
  "options": [
   "제품개발 - PLM / PDM",
   "공정관리 - MES / POP",
   "설비관리 – CMMS",
   "품질관리 - WMS"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-068",
  "type": "choice",
  "question": "제조현장 밀착형 시스템(MES)과 경영적 의사결정지원 시스템(ERP)의 관계에 대한 설명으로 옳은 것은?",
  "options": [
   "ERP와 MES는 서로 데이터를 공유할 필요가 없는 독립 시스템이다.",
   "MES는 공정별 실시간 관리 및 추적성을 제공하고,ERP는 이를 바탕으로 영업/구매/생산 등의 의사결정을 지원한다.",
   "MES는 재무회계 기능을 전담하고,ERP는 설비 인터페이스를 전담한다.",
   "ERP를 도입하면 MES는 자동으로 불필요해진다."
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-069",
  "type": "choice",
  "question": "PLM(제품수명주기관리)과 PDM(제품데이터관리)의 차이점에 대한 설명으로 옳은 것은?",
  "options": [
   "PDM이 PLM보다 훨씬 더 넓은 범위(양산,폐기까지)를 관리한다.",
   "PDM은 설계·개발 단계의 도면,E-BOM 등 산출물 관리에 초점을 두고,PLM은 제품 기획부터 폐기까지 전체 라이프사이클을 관리한다.",
   "PLM 2.0은 오직 연구개발조직 내부에서만 사용하는 CAD 중심 단계이다.",
   "PDM은 제조현장의 설비 가동률만 전문적으로 관리하는 시스템이다."
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-070",
  "type": "choice",
  "question": "MES와 POP(생산시점관리 시스템)의 관계에 대한 설명으로 가장 옳은 것은?",
  "options": [
   "POP를 운영하는 기업은 MES를 운영하는 기업보다 무조건 수준이 낮다.",
   "POP는 생산실적 위주의 실행 부문이며,MES는 계획 최적화(MRP/CRP)와 실행을 통합 관리하는 개념이다.",
   "POP는 현장 디바이스와 실시간 연계가 필요 없다.",
   "MES는 오직 수작업으로만 데이터를 입력받는 시스템이다."
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-071",
  "type": "choice",
  "question": "설비 보전 활동 유형 중 '설비의 열화 상태를 수집된 측정 데이터와 그 해석에 따라 판단하여 보전하는 방식'은?",
  "options": [
   "사후 보전 (BM)",
   "정기 보전 (TBM)",
   "예지 보전 (CBM)",
   "긴급 사후 보전 (EBM)"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-072",
  "type": "choice",
  "question": "CMMS(설비보전관리시스템)에서 관리하는 주요 유지보수 성과지표(KPI)인 MTBF와 MTTR의 의미로 옳은 것은?",
  "options": [
   "MTBF(평균고장간격),MTTR(평균수리시간)",
   "MTBF(평균수리시간),MTTR(평균고장간격)",
   "MTBF(최대생산량),MTTR(최소불량률)",
   "MTBF(설비가동률),MTTR(에너지효율)"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-073",
  "type": "choice",
  "question": "QMS(품질관리시스템)에서 양산단계의 초중종물 검사 결과를 입력할 때 가장 바람직한 방식은?",
  "options": [
   "작업자가 종이에 적은 후 퇴근 전 일괄 키보드 입력",
   "IoT 센서 기술 기반 측정기기로 자동 측정 및 시스템 자동 입력",
   "구두로 품질팀장에게 보고 후 생략",
   "월말에 한 번에 추정치 입력"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-074",
  "type": "choice",
  "question": "SCM(공급망 관리 시스템)의 핵심 목적으로 옳지 않은 것은?",
  "options": [
   "시장 수요와 공급 간 최적 균형 유지",
   "고객사부터 공급사까지 실시간 정보 공유",
   "원자재·재공·제품 재고의 극대화",
   "정시/정량 공급 및 적기 생산·배송"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-075",
  "type": "choice",
  "question": "WMS(물류창고 관리 시스템)의 관리 포인트로 적절하지 않은 것은?",
  "options": [
   "현물정보와 전산정보의 일치",
   "선입선출(FIFO)의 준수",
   "데이터 집계 포인트에서 자동집계",
   "창고 내 자재 위치(Location)의 임의 변경 및 비공개"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-076",
  "type": "choice",
  "question": "ERP(전사적자원관리) 운영 시 BOM 정보의 오류나 입고 정보 지연이 발생했을 때 나타나는 현상은?",
  "options": [
   "타 부문에서 잘못된 의사결정을 내리게 된다.",
   "ERP가 스스로 오류를 수정하여 정상 작동한다.",
   "재무회계 데이터만 정확해진다.",
   "생산계획이 자동으로 최적화된다."
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-077",
  "type": "choice",
  "question": "환경관리시스템(EMS) 적용 사례 중 '사업장 폐기물의 배출부터 운반, 처리까지 전 과정을 온라인으로 관리하는 시스템'은?",
  "options": [
   "올바로(Allbaro) 시스템",
   "그린링크(GreenLink)",
   "TMS(원격감시시스템)",
   "SHMIS"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-078",
  "type": "choice",
  "question": "굴뚝이나 폐수배출구 등 고정오염원에 부착하여 배출되는 오염물질을 24시간 감시하는 환경부 주관의 법적 강제 시스템은?",
  "options": [
   "올바로 시스템",
   "TMS (Tele Monitoring System)",
   "FEMS",
   "SCADA"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-079",
  "type": "choice",
  "question": "소규모 대기배출시설(4~5종)에 IoT 측정기기 부착이 의무화됨에 따라 가동 데이터를 실시간 전송하는 시스템은?",
  "options": [
   "그린링크 (GreenLink)",
   "올바로 시스템",
   "ERP",
   "PLM"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-080",
  "type": "choice",
  "question": "안전보건관리정보시스템(SHMIS)에 대한 설명으로 옳은 것은?",
  "options": [
   "안전점검,위험성평가 등 PDCA 활동을 지원하며 모바일 환경 운영이 중요하다.",
   "오직 대기업만 사용할 수 있고 SaaS 형태는 존재하지 않는다.",
   "생산량 증대만을 목적으로 하는 시스템이다.",
   "설비의 가공 정밀도를 측정하는 시스템이다."
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-081",
  "type": "choice",
  "question": "DX(디지털 전환)와 AX(AI 전환)의 관계에 대한 설명으로 옳은 것은?",
  "options": [
   "DX는 AX와 전혀 무관한 별개의 개념이다.",
   "DX는 AX를 위한 필수적인 기초 토대이며,AX는 DX의 완성도를 높이는 고도화 단계이다.",
   "AX가 먼저 선행된 후에야 DX가 가능하다.",
   "DX는 자율화가 목적이고,AX는 단순 전산화가 목적이다."
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-082",
  "type": "choice",
  "question": "다음 중 AX(AI Transformation)의 핵심 기술 및 가치로 가장 적절한 것은?",
  "options": [
   "단순 문서 스캔 / 아날로그 보존",
   "생성형 AI,LLM / 자율화 및 지능화",
   "수기 장부 / 부분적 효율화",
   "오프라인 결재 / 인력 증원"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-083",
  "type": "choice",
  "question": "제조기업에서 정보시스템 도입이 실패하는 주요 원인으로 교재에서 지적한 것은?",
  "options": [
   "장기계획(ISP) 수립",
   "프로세스 표준화 없이 인원 절감이나 원가 절감 수단으로만 도입",
   "종업원 만족과 고객 만족을 목표로 도입",
   "현장 데이터의 실시간 공유"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-084",
  "type": "choice",
  "question": "PLM의 발전 단계 중 고객이 제품기획과 시험 등 개발과정에 직접 참여하고 사내/사외 IT솔루션과 연동되는 단계는?",
  "options": [
   "1단계 (CAD)",
   "2단계 (PDM)",
   "3단계 (PLM 1.0)",
   "4단계 (PLM 2.0)"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-085",
  "type": "choice",
  "question": "WMS와 WCS(창고제어시스템)를 결합하여 IT 기술을 바탕으로 ERP와 창고 자동화 설비를 접목해 재고흐름을 최적화하는 개념은?",
  "options": [
   "WES (Warehouse Execution System)",
   "MES (Manufacturing Execution System)",
   "QMS (Quality Management System)",
   "FEMS (Factory Energy Management System)"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-086",
  "type": "choice",
  "question": "스마트공장의 3대 핵심 특징으로 옳은 것은?",
  "options": [
   "단순화,수직화,무인화",
   "지능화(Intelligence),연결화(Connectivity),가상화(Virtualization)",
   "중앙화,폐쇄화,아날로그화",
   "분산화,수작업화,일회성"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-087",
  "type": "choice",
  "question": "조립 산업과 장치 산업의 스마트공장 지향점으로 옳은 것은?",
  "options": [
   "조립 산업은 다품종 대량생산(Mass Customization),장치 산업은 Data 기반 예측 가능한 공장",
   "조립 산업은 소품종 대량생산,장치 산업은 수작업 중심 공장",
   "두 산업 모두 자동화 설비만 도입하고 데이터 분석은 배제",
   "조립 산업은 공정 제어만,장치 산업은 조립 로봇만 도입"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-088",
  "type": "choice",
  "question": "제조기업의 디지털 혁신 3대 방향에 해당하지 않는 것은?",
  "options": [
   "운영 효율화 (Operation Excellence)",
   "제품에 서비스 부가가치 결합 (Product + Service)",
   "새로운 비즈니스 모델 창출 (New Business)",
   "기존 아날로그 방식의 영구 고수"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-089",
  "type": "choice",
  "question": "기존 공장을 대상으로 설비를 교체하거나 업그레이드하며 시범 라인 구축을 통해 단계별로 스마트공장을 추진하는 투자 형태는?",
  "options": [
   "Green Field (직접투자)",
   "Brown Field (M&A형/기존공장 업그레이드)",
   "Blue Ocean",
   "Black Box"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-090",
  "type": "choice",
  "question": "제4차 산업혁명의 3대 핵심 특징으로 옳은 것은?",
  "options": [
   "기계화,전기화,자동화",
   "초연결성,초지능화,융합화",
   "증기기관,컨베이어 벨트,컴퓨터",
   "대량생산,표준화,분업화"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-091",
  "type": "choice",
  "question": "전통적인 '파이프라인(Pipeline)' 비즈니스 모델에서 '플랫폼(Platform)' 비즈니스 모델로의 변화에 대한 설명으로 옳은 것은?",
  "options": [
   "플랫폼은 사람,조직,자원 등을 연결하여 거래 비용을 낮추고 새로운 가치를 창출한다.",
   "파이프라인 모델이 플랫폼 모델보다 공유 및 협업 체계에 더 유리하다.",
   "플랫폼 모델은 오직 아날로그 방식만을 고수한다.",
   "제조업에서는 플랫폼 모델을 적용할 수 없다."
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-092",
  "type": "choice",
  "question": "디지털 혁신의 진화 과정을 순서대로 올바르게 나열한 것은?",
  "options": [
   "Digitalization → Digitization → Digital Transformation",
   "Digitization(아날로그의 디지털화) → Digitalization(프로세스의 디지털화) → Digital Transformation(비즈니스 모델 혁신)",
   "Digital Transformation → Digitalization → Digitization",
   "Digitization → Digital Transformation → Digitalization"
  ],
  "answer": 2,
  "explanation": ""
 },
 {
  "id": "G-093",
  "type": "choice",
  "question": "기업이 디지털 전환(DX) 프로젝트 추진에 실패하는 4가지 주요 요인에 해당하지 않는 것은?",
  "options": [
   "변화를 싫어하는 조직문화",
   "경영진의 낮은 디지털 역량",
   "클리닝되지 않은 비효율적인 데이터 분석",
   "고객과의 지나치게 긴밀하고 일관된 협력"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-094",
  "type": "choice",
  "question": "글로벌 스마트팩토리 트렌드 중 '컴퓨터의 플러그 앤 플레이처럼 새로운 생산 장비나 로봇을 공정에 즉시 연결해 별도 설정 없이 생산을 시작하는 유연한 제조 방식'은?",
  "options": [
   "Plug & Manufacturing",
   "Mass Production",
   "Lean Production",
   "Waterfall Manufacturing"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-095",
  "type": "choice",
  "question": "인간중심 제조(Human-Oriented Manufacturing)에서 인간과 로봇의 작업 방식 중 '같은 작업 공간에서 서로 상호작용을 수행(예: 로봇이 인간에게 부품을 전달)하는 형태'는?",
  "options": [
   "공존 (Coexistence)",
   "협력 (Cooperation)",
   "협업 (Collaboration)",
   "분리 (Separation)"
  ],
  "answer": 3,
  "explanation": ""
 },
 {
  "id": "G-096",
  "type": "choice",
  "question": "국제표준 IEC 63278-1에 정의된 AAS(자산관리쉘)의 구성요소 3가지로 옳은 것은?",
  "options": [
   "서브모델(Submodel),프로퍼티(Property),어트리뷰트(Attribute)",
   "하드웨어,소프트웨어,펌웨어",
   "입력,처리,출력",
   "센서,제어기,액추에이터"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-097",
  "type": "choice",
  "question": "AAS(자산관리쉘)에서 프로퍼티의 의미를 명확히 하기 위한 시멘틱 식별자로, 자체 정의 시 사용해야 하는 표준 형식은?",
  "options": [
   "URI 형식",
   "IP 주소 형식",
   "전화번호 형식",
   "우편번호 형식"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-098",
  "type": "choice",
  "question": "DX를 넘어 AX(AI 전환)를 추진하기 위한 AAS 서브모듈 구조설계(P, Q, M, O) 중 '공정이 어떻게 진행되고 언제 일어나며 어떤 상태인지를 나타내는 공정 흐름과 제어 데이터'를 다루는 모델은?",
  "options": [
   "Process Model (P)",
   "Quality Model (Q)",
   "Maintenance Model (M)",
   "Operator Model (O)"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "G-099",
  "type": "choice",
  "question": "AAS 서브모듈 구조설계(P, Q, M, O) 중 '작업자 ID, 숙련도 레벨, AI 도구 활용률 등 사람과 AI의 협업을 관리하는 모델'은?",
  "options": [
   "Process Model (P)",
   "Quality Model (Q)",
   "Maintenance Model (M)",
   "Operator Model (O)"
  ],
  "answer": 4,
  "explanation": ""
 },
 {
  "id": "G-100",
  "type": "choice",
  "question": "디지털 엔지니어링 이니셔티브(DEI)에서 제품의 설계(CAD), 해석(CAE), 생산(CAM) 등 제조 전 과정을 컴퓨터 기술로 지원하는 통합 기술을 무엇이라 하는가?",
  "options": [
   "CAx (Computer-aided Technologies)",
   "MES",
   "ERP",
   "WMS"
  ],
  "answer": 1,
  "explanation": ""
 },
 {
  "id": "C-001",
  "type": "choice",
  "question": "스마트공장 수준확인 제도의 설명으로 가장 옳은 것은?",
  "options": [
   "정부 구축 지원금의 지급 여부를 결정하는 제도",
   "공급기업의 기술 역량을 평가해 등록하는 제도",
   "제조기업의 스마트화 수준을 합의된 절차와 기준에 따라 공신력 있는 기관이 확인·검증하는 제도",
   "스마트공장 분야 국가기술자격을 검정하는 제도"
  ],
  "answer": 3,
  "explanation": "수준확인의 규정상 정의"
 },
 {
  "id": "C-002",
  "type": "choice",
  "question": "2026년도 스마트공장 수준확인 사업을 공고한 부처는?",
  "options": [
   "중소벤처기업부",
   "고용노동부",
   "과학기술정보통신부",
   "국토교통부"
  ],
  "answer": 1,
  "explanation": "중소벤처기업부 공고 제2026-45호"
 },
 {
  "id": "C-003",
  "type": "choice",
  "question": "2026년도 수준확인 사업 공고에서 제시한 지원 규모는?",
  "options": [
   "500개사",
   "1,000개사",
   "1,500개사",
   "2,000개사"
  ],
  "answer": 4,
  "explanation": "2,000개사 지원"
 },
 {
  "id": "C-004",
  "type": "choice",
  "question": "2026년도 수준확인 사업의 기업당 지원 조건은?",
  "options": [
   "비용의 50%, 최대 50만 원",
   "비용 전액, 최대 100만 원",
   "비용의 70%, 최대 200만 원",
   "비용 전액, 최대 300만 원"
  ],
  "answer": 2,
  "explanation": "비용 전액, 기업당 최대 백만 원"
 },
 {
  "id": "C-005",
  "type": "choice",
  "question": "2026년도 수준확인 사업의 지원 제외 대상이 아닌 것은?",
  "options": [
   "휴업 또는 폐업 중인 기업",
   "수준확인서 유효기간이 만료된 기업",
   "국세 및 지방세를 체납 중인 기업",
   "스마트공장 구축사업에 참여 중인 기업"
  ],
  "answer": 2,
  "explanation": "유효기간 만료 기업은 신청 대상"
 },
 {
  "id": "C-006",
  "type": "choice",
  "question": "다음 중 수준확인 사업에 신청할 수 없는 기업은?",
  "options": [
   "현재 자체 스마트공장을 구축 중인 기업",
   "자체 역량으로 스마트공장을 구축한 정부사업 미참여 기업",
   "자발적 고도화로 수준 상승이 기대되는 기업",
   "수준확인서 유효기간이 만료된 기업"
  ],
  "answer": 1,
  "explanation": "자체 구축 중이면 신청 불가"
 },
 {
  "id": "C-007",
  "type": "choice",
  "question": "2026년 수준확인 사업의 확인기관으로 안내된 기관은?",
  "options": [
   "한국표준협회, 한국건설생활환경시험연구원",
   "중소벤처기업진흥공단, 중소기업기술정보진흥원",
   "스마트제조혁신협회, 대한상공회의소",
   "지역 테크노파크, 대한무역투자진흥공사"
  ],
  "answer": 3,
  "explanation": "2026년 확인기관은 두 곳"
 },
 {
  "id": "C-008",
  "type": "choice",
  "question": "수준확인 사업의 신청 방법은?",
  "options": [
   "관할 지방중소벤처기업청에 우편 제출",
   "확인기관 방문 접수",
   "심사원에게 이메일 제출",
   "스마트공장 사업관리시스템 온라인 접수"
  ],
  "answer": 4,
  "explanation": "사업관리시스템(smart-factory.kr) 온라인 신청"
 },
 {
  "id": "C-009",
  "type": "choice",
  "question": "2026년도 정부형 스마트공장 구축사업의 회당 정부 지원 조건은?",
  "options": [
   "최대 0.5억 원, 30% 이내",
   "최대 1억 원, 40% 이내",
   "최대 2억 원, 50% 이내",
   "최대 5억 원, 70% 이내"
  ],
  "answer": 3,
  "explanation": "회당 최대 2억 원, 50% 이내(수준별 2.5억 원 한도)"
 },
 {
  "id": "C-010",
  "type": "choice",
  "question": "2026년도 정부형 스마트공장 구축사업에서 요구한 구축 목표수준은?",
  "options": [
   "중간1 이상",
   "기초 이상",
   "중간2 이상",
   "고도 이상"
  ],
  "answer": 1,
  "explanation": "목표수준 중간1 이상 설정"
 },
 {
  "id": "C-011",
  "type": "choice",
  "question": "세부관리기준이 정의한 ‘자율형공장’의 설명으로 옳은 것은?",
  "options": [
   "작업 지시를 모두 종이 문서로 전달하는 공장",
   "기업이 자기 자금만으로 건설한 공장",
   "여러 기업이 공동으로 소유한 공장",
   "AI·디지털트윈 기반 실시간 관제, 분석·예측 등으로 작업자 개입을 최소화하는 스마트공장"
  ],
  "answer": 4,
  "explanation": "자율형공장의 규정상 정의"
 },
 {
  "id": "C-012",
  "type": "choice",
  "question": "수준확인 지원기업이 받는 결과물로 옳게 짝지은 것은?",
  "options": [
   "구축계획서, 원가계산서",
   "수준확인서, 심사보고서",
   "감리보고서, 기술임치증",
   "자격증, 교육 수료증"
  ],
  "answer": 2,
  "explanation": "수준확인서와 심사보고서 제공"
 },
 {
  "id": "C-013",
  "type": "choice",
  "question": "KS X 9001-3의 프로세스 관점 6개 구성요소가 아닌 것은?",
  "options": [
   "제품개발",
   "공정관리",
   "설비관리",
   "재무회계"
  ],
  "answer": 4,
  "explanation": "제품개발, 생산계획, 공정관리, 품질관리, 설비관리, 물류관리"
 },
 {
  "id": "C-014",
  "type": "choice",
  "question": "스마트공장 참조모델의 수직적 영역을 옳게 나열한 것은?",
  "options": [
   "현장자동화, 제어자동화, 응용시스템",
   "기획, 판매, 사후서비스",
   "설계, 구매, 재무",
   "사내망, 외부망, 무선망"
  ],
  "answer": 1,
  "explanation": "수직적으로 세 영역을 포함"
 },
 {
  "id": "C-015",
  "type": "choice",
  "question": "참조모델에서 수준을 정의하는 요소 4M+1E의 ‘E’는?",
  "options": [
   "Efficiency",
   "Energy",
   "Environment",
   "Engineering"
  ],
  "answer": 3,
  "explanation": "Man, Materials, Machinery, Methods, Environment"
 },
 {
  "id": "C-016",
  "type": "choice",
  "question": "BOM에 대한 설명으로 옳은 것은?",
  "options": [
   "설비의 고장 이력을 기록한 문서",
   "제품을 구성하는 부품·자재의 목록과 수량, 계층 구조",
   "작업자의 근태 기록",
   "출하 차량의 배차 계획"
  ],
  "answer": 2,
  "explanation": "Bill of Materials"
 },
 {
  "id": "C-017",
  "type": "choice",
  "question": "제품·공정의 잠재적 고장 형태와 영향을 사전에 분석하는 기법은?",
  "options": [
   "VOC",
   "PERT",
   "FMEA",
   "ABC 분석"
  ],
  "answer": 3,
  "explanation": "고장형태 및 영향 분석"
 },
 {
  "id": "C-018",
  "type": "choice",
  "question": "물류·자재 관리에서 선입선출(FIFO)의 주된 목적은?",
  "options": [
   "먼저 입고된 자재를 먼저 사용해 장기 재고와 품질 저하를 줄이는 것",
   "비싼 자재부터 사용해 원가를 높이는 것",
   "설비 가동 시간을 늘리는 것",
   "작업자 수를 고정하는 것"
  ],
  "answer": 1,
  "explanation": "선입선출로 장기 재고를 방지"
 },
 {
  "id": "C-019",
  "type": "choice",
  "question": "기준생산계획, BOM, 재고 정보를 바탕으로 필요한 자재의 양과 시점을 계산하는 기법은?",
  "options": [
   "TPM",
   "MRP",
   "SPC",
   "5S"
  ],
  "answer": 2,
  "explanation": "자재소요계획"
 },
 {
  "id": "C-020",
  "type": "choice",
  "question": "설비 능력과 자재 등 제약조건을 고려해 생산 일정을 최적화하는 시스템은?",
  "options": [
   "CAD",
   "HRM",
   "CRM",
   "APS"
  ],
  "answer": 4,
  "explanation": "고급계획 및 스케줄링"
 },
 {
  "id": "C-021",
  "type": "choice",
  "question": "관리도 등을 활용해 공정의 변동을 감시하고 관리하는 기법은?",
  "options": [
   "BPR",
   "JIT",
   "SPC",
   "OJT"
  ],
  "answer": 3,
  "explanation": "통계적 공정관리"
 },
 {
  "id": "C-022",
  "type": "choice",
  "question": "설비종합효율(OEE)의 일반적인 계산식은?",
  "options": [
   "시간가동률 × 성능가동률 × 양품률",
   "생산량 ÷ 작업자 수",
   "매출액 ÷ 설비투자액",
   "불량수량 ÷ 검사수량"
  ],
  "answer": 1,
  "explanation": "시간·성능·양품 세 요소의 곱"
 },
 {
  "id": "C-023",
  "type": "choice",
  "question": "PLC의 역할로 가장 옳은 것은?",
  "options": [
   "전사 회계 처리",
   "입력 신호를 받아 프로그램에 따라 설비 출력을 제어",
   "제품 3차원 형상 설계",
   "고객 주문 접수"
  ],
  "answer": 2,
  "explanation": "프로그램 가능 논리 제어기"
 },
 {
  "id": "C-024",
  "type": "choice",
  "question": "SCADA의 설명으로 옳은 것은?",
  "options": [
   "인사 평가 시스템",
   "제품 수명주기 관리 시스템",
   "창고 위치 관리 시스템",
   "원격 설비·공정을 감시·제어하고 데이터를 수집하는 시스템"
  ],
  "answer": 4,
  "explanation": "원격 감시제어 및 데이터 수집"
 },
 {
  "id": "C-025",
  "type": "choice",
  "question": "HMI의 설명으로 옳은 것은?",
  "options": [
   "작업자와 기계 사이에서 정보 표시와 조작을 담당하는 인터페이스",
   "재고 원가 계산 방식",
   "공급업체 평가 지표",
   "무선 통신 규격의 하나"
  ],
  "answer": 1,
  "explanation": "사람-기계 인터페이스"
 },
 {
  "id": "C-026",
  "type": "choice",
  "question": "카메라와 영상처리 기술로 제품의 외관 불량을 자동 판정하는 기술은?",
  "options": [
   "로드셀",
   "인버터",
   "머신비전",
   "서보모터"
  ],
  "answer": 3,
  "explanation": "영상 기반 자동 검사"
 },
 {
  "id": "C-027",
  "type": "choice",
  "question": "AGV와 비교한 AMR의 특징으로 옳은 것은?",
  "options": [
   "바닥 유도선 없이는 움직일 수 없다",
   "사람이 직접 운전해야 한다",
   "주변 환경을 인식해 경로를 스스로 변경할 수 있다",
   "물건을 운반할 수 없다"
  ],
  "answer": 3,
  "explanation": "AMR은 자율 경로 생성"
 },
 {
  "id": "C-028",
  "type": "choice",
  "question": "협동로봇의 특징으로 가장 옳은 것은?",
  "options": [
   "반드시 안전펜스 안에서 사람과 분리해 운용한다",
   "안전 기능을 갖추고 사람과 작업 공간을 공유할 수 있다",
   "프로그램 변경이 불가능하다",
   "물류 작업에만 쓴다"
  ],
  "answer": 2,
  "explanation": "안전 기능을 전제로 공간 공유. 위험성 평가는 필요"
 },
 {
  "id": "C-029",
  "type": "choice",
  "question": "바코드와 비교한 RFID의 특징으로 옳은 것은?",
  "options": [
   "무선으로 비접촉 인식이 가능하고 다수 태그의 동시 판독에 유리하다",
   "반드시 인쇄면이 보여야 한다",
   "한 번에 하나만 접촉식으로 읽는다",
   "데이터를 전혀 저장하지 못한다"
  ],
  "answer": 1,
  "explanation": "무선·비접촉 다중 인식"
 },
 {
  "id": "C-030",
  "type": "choice",
  "question": "서로 다른 제조사의 설비·시스템 간 데이터 상호운용을 위한 산업 통신 표준은?",
  "options": [
   "HTML",
   "JPEG",
   "SMTP",
   "OPC UA"
  ],
  "answer": 4,
  "explanation": "산업용 상호운용 통신 표준"
 },
 {
  "id": "C-031",
  "type": "choice",
  "question": "구매, 재무, 인사 등 전사 경영자원을 통합 관리하는 시스템은?",
  "options": [
   "PLC",
   "MES",
   "ERP",
   "AGV"
  ],
  "answer": 3,
  "explanation": "전사적 자원관리"
 },
 {
  "id": "C-032",
  "type": "choice",
  "question": "현장의 작업지시, 실적, 공정 상태를 실시간으로 관리하는 제조실행시스템은?",
  "options": [
   "MES",
   "CRM",
   "HRM",
   "DBMS"
  ],
  "answer": 1,
  "explanation": "제조실행시스템"
 },
 {
  "id": "C-033",
  "type": "choice",
  "question": "제품의 기획부터 폐기까지 수명주기 데이터를 관리하는 시스템은?",
  "options": [
   "SCADA",
   "WMS",
   "FEMS",
   "PLM"
  ],
  "answer": 4,
  "explanation": "제품 수명주기 관리"
 },
 {
  "id": "C-034",
  "type": "choice",
  "question": "협력사부터 고객까지 공급망의 정보·자재 흐름을 관리하는 시스템은?",
  "options": [
   "CAE",
   "SCM",
   "POP",
   "HMI"
  ],
  "answer": 2,
  "explanation": "공급망 관리"
 },
 {
  "id": "C-035",
  "type": "choice",
  "question": "창고의 입출고, 재고, 로케이션을 관리하는 시스템은?",
  "options": [
   "CAD",
   "APS",
   "PLC",
   "WMS"
  ],
  "answer": 4,
  "explanation": "창고관리시스템"
 },
 {
  "id": "C-036",
  "type": "choice",
  "question": "공장의 에너지 사용량을 모니터링하고 절감을 지원하는 시스템은?",
  "options": [
   "QMS",
   "FEMS",
   "PDM",
   "TMS"
  ],
  "answer": 2,
  "explanation": "공장 에너지 관리시스템"
 },
 {
  "id": "C-037",
  "type": "choice",
  "question": "생산 현장에서 발생하는 실적 정보를 발생 시점에 수집하는 생산시점관리는?",
  "options": [
   "POP",
   "BOM",
   "MPS",
   "VMI"
  ],
  "answer": 1,
  "explanation": "Point of Production"
 },
 {
  "id": "C-038",
  "type": "choice",
  "question": "ISA-95 계층 모델에서 MES 등 제조운영관리가 주로 위치하는 수준은?",
  "options": [
   "Level 0",
   "Level 1",
   "Level 3",
   "Level 5"
  ],
  "answer": 3,
  "explanation": "Level 3가 제조운영관리"
 },
 {
  "id": "C-039",
  "type": "choice",
  "question": "컴퓨터로 구조·유동 등을 해석해 설계를 검증하는 도구는?",
  "options": [
   "ERP",
   "OCR",
   "RPA",
   "CAE"
  ],
  "answer": 4,
  "explanation": "컴퓨터 이용 공학 해석"
 },
 {
  "id": "C-040",
  "type": "choice",
  "question": "응용 소프트웨어를 인터넷으로 구독해 사용하는 클라우드 서비스 형태는?",
  "options": [
   "SaaS",
   "온프레미스",
   "IaaS",
   "VPN"
  ],
  "answer": 1,
  "explanation": "Software as a Service"
 },
 {
  "id": "C-041",
  "type": "choice",
  "question": "KS X 9001에서 설명하는 스마트공장으로 가장 옳은 것은?",
  "options": [
   "사람을 전혀 투입하지 않는 무인 공장만을 뜻한다",
   "기획·설계·생산·유통·판매 등 제조 전 과정을 ICT로 통합해 최소 비용·시간으로 고객 맞춤형 제품 생산을 지향하는 공장",
   "로봇 설비를 일정 대수 이상 갖춘 공장",
   "ERP를 도입한 모든 기업"
  ],
  "answer": 2,
  "explanation": "KS X 9001의 스마트공장 정의"
 },
 {
  "id": "C-042",
  "type": "choice",
  "question": "KS X 9001-3의 표준명으로 옳은 것은?",
  "options": [
   "기본 개념과 구조",
   "용어",
   "운영관리시스템(진단평가모델)",
   "정보보호 관리체계"
  ],
  "answer": 3,
  "explanation": "1부 기본 개념과 구조, 2부 용어, 3부 운영관리시스템"
 },
 {
  "id": "C-043",
  "type": "choice",
  "question": "KS X 9001-1, -2, -3이 제정된 시기는?",
  "options": [
   "2016년 6월",
   "2010년 1월",
   "2020년 12월",
   "2024년 3월"
  ],
  "answer": 1,
  "explanation": "세 표준 모두 2016년 6월 제정"
 },
 {
  "id": "C-044",
  "type": "choice",
  "question": "2014년 참조모델에서 정의한 스마트공장 수준을 낮은 순서로 옳게 나열한 것은?",
  "options": [
   "기초 → ICT 미적용 → 중간1 → 고도화 → 중간2",
   "중간1 → 중간2 → 기초 → 고도화 → ICT 미적용",
   "ICT 미적용 → 중간1 → 기초 → 중간2 → 고도화",
   "ICT 미적용 → 기초 → 중간1 → 중간2 → 고도화"
  ],
  "answer": 4,
  "explanation": "2014년 10월 참조모델의 5단계"
 },
 {
  "id": "C-045",
  "type": "choice",
  "question": "스마트공장 생태계의 주요 주체인 애플리케이션, 플랫폼, 디바이스에 해당하지 않는 것은?",
  "options": [
   "MES 소프트웨어",
   "오프라인 판매 대리점",
   "데이터 수집·분석 플랫폼",
   "센서"
  ],
  "answer": 2,
  "explanation": "판매 대리점은 기술 구성 주체가 아님"
 },
 {
  "id": "C-046",
  "type": "choice",
  "question": "KS X 9001-3 운영관리시스템 프레임워크의 5개 계층이 아닌 것은?",
  "options": [
   "고객서비스",
   "비전 및 전략",
   "제조운영",
   "기계 및 제어"
  ],
  "answer": 1,
  "explanation": "비전 및 전략, 목표 및 성과, 기업경영, 제조운영, 기계 및 제어"
 },
 {
  "id": "C-047",
  "type": "choice",
  "question": "스마트공장에서 ICT와 대비되는 OT의 의미로 옳은 것은?",
  "options": [
   "Office Tool",
   "Online Trade",
   "Operational Technology",
   "Order Tracking"
  ],
  "answer": 3,
  "explanation": "운영기술"
 },
 {
  "id": "C-048",
  "type": "choice",
  "question": "공정 불량률이 1.8%에서 0.87%로 낮아졌다면 감소율은 약 얼마인가?",
  "options": [
   "10%",
   "23%",
   "37%",
   "52%"
  ],
  "answer": 4,
  "explanation": "(1.8−0.87)÷1.8 = 약 51.7%"
 },
 {
  "id": "C-049",
  "type": "choice",
  "question": "현실의 설비·공정을 가상공간에 복제해 데이터를 연동하고 시뮬레이션하는 기술은?",
  "options": [
   "블록체인",
   "전자서명",
   "디지털 트윈",
   "텔레매틱스"
  ],
  "answer": 3,
  "explanation": "가상 복제와 실시간 연동"
 },
 {
  "id": "C-050",
  "type": "choice",
  "question": "물리 시스템과 컴퓨팅·네트워크가 결합해 상호작용하는 시스템은?",
  "options": [
   "CPS",
   "ETL",
   "LAN",
   "CMS"
  ],
  "answer": 1,
  "explanation": "사이버물리시스템"
 },
 {
  "id": "C-051",
  "type": "choice",
  "question": "‘Industry 4.0’ 전략을 제조업 혁신 정책으로 처음 제시한 국가는?",
  "options": [
   "미국",
   "일본",
   "중국",
   "독일"
  ],
  "answer": 4,
  "explanation": "독일의 제조업 전략"
 },
 {
  "id": "C-052",
  "type": "choice",
  "question": "피지컬 AI의 설명으로 가장 옳은 것은?",
  "options": [
   "문서만 요약하는 AI",
   "로봇 등 물리적 장치를 통해 현실 환경을 인지·판단하고 행동하는 AI",
   "체력 측정 전용 프로그램",
   "서버 하드웨어의 다른 이름"
  ],
  "answer": 2,
  "explanation": "물리 환경에서 행동하는 AI"
 },
 {
  "id": "C-053",
  "type": "choice",
  "question": "제조 분야에서 AX가 일반적으로 뜻하는 것은?",
  "options": [
   "인공지능 전환",
   "자동 수출",
   "회계 감사",
   "축 제어 장치"
  ],
  "answer": 1,
  "explanation": "AI Transformation"
 },
 {
  "id": "C-054",
  "type": "choice",
  "question": "철강 등 수입품의 탄소 배출량에 비용을 부과하는 EU 제도는?",
  "options": [
   "GDPR",
   "REACH",
   "CBAM",
   "RoHS"
  ],
  "answer": 3,
  "explanation": "탄소국경조정제도"
 },
 {
  "id": "C-055",
  "type": "choice",
  "question": "제조 DX 추진 관점으로 가장 적절한 것은?",
  "options": [
   "최신 장비 구매 자체를 목표로 삼는다",
   "데이터 표준화 없이 시스템 수만 늘린다",
   "현장 의견을 배제하고 IT 부서만 추진한다",
   "업무 프로세스와 조직 역량의 변화를 기술 도입과 함께 추진한다"
  ],
  "answer": 4,
  "explanation": "기술과 프로세스·조직을 함께 변화"
 },
 {
  "id": "C-056",
  "type": "choice",
  "question": "데이터 발생 지점 가까이에서 처리해 지연을 줄이는 컴퓨팅 방식은?",
  "options": [
   "메인프레임 일괄 처리",
   "엣지 컴퓨팅",
   "수기 집계",
   "오프사이트 백업"
  ],
  "answer": 2,
  "explanation": "현장 근처에서 처리"
 },
 {
  "id": "C-057",
  "type": "choice",
  "question": "설비 상태 데이터로 고장 시점을 예측해 정비하는 방식은?",
  "options": [
   "사후보전",
   "예지보전",
   "일상청소",
   "개량보전"
  ],
  "answer": 2,
  "explanation": "상태 기반 고장 예측"
 },
 {
  "id": "C-058",
  "type": "choice",
  "question": "양품·불량 정답이 표시된 이미지로 불량 판정 모델을 학습하는 방식은?",
  "options": [
   "지도학습",
   "비지도 군집화",
   "강화학습",
   "수기 규칙 작성"
  ],
  "answer": 1,
  "explanation": "정답 레이블로 학습"
 },
 {
  "id": "C-059",
  "type": "choice",
  "question": "불량 데이터가 매우 적을 때 주로 정상 데이터로 학습해 벗어난 패턴을 찾는 접근은?",
  "options": [
   "환율 예측",
   "문서 번역",
   "음성 합성",
   "이상탐지"
  ],
  "answer": 4,
  "explanation": "정상 패턴에서 벗어난 것을 탐지"
 },
 {
  "id": "C-060",
  "type": "choice",
  "question": "5G의 주요 특성이 아닌 것은?",
  "options": [
   "초고속",
   "초저지연",
   "유선 케이블 전용 연결",
   "초연결"
  ],
  "answer": 3,
  "explanation": "5G는 무선 통신"
 },
 {
  "id": "C-061",
  "type": "choice",
  "question": "스마트공장 OT 보안 관리로 부적절한 것은?",
  "options": [
   "설비의 초기 비밀번호를 그대로 유지한다",
   "네트워크를 구역별로 분리한다",
   "접근 권한을 최소화한다",
   "접속 로그를 점검한다"
  ],
  "answer": 1,
  "explanation": "초기 비밀번호는 즉시 변경"
 },
 {
  "id": "C-062",
  "type": "choice",
  "question": "작업자의 시야에 작업 지시와 정보를 겹쳐 보여 주는 기술은?",
  "options": [
   "OCR",
   "ETL",
   "RPA",
   "AR(증강현실)"
  ],
  "answer": 4,
  "explanation": "현실에 디지털 정보를 겹침"
 },
 {
  "id": "C-063",
  "type": "choice",
  "question": "적층제조(3D 프린팅)의 원리로 옳은 것은?",
  "options": [
   "소재를 깎아 내어 형상을 만든다",
   "재료를 층층이 쌓아 형상을 만든다",
   "금형에 녹인 재료를 사출한다",
   "판재를 눌러 구부린다"
  ],
  "answer": 2,
  "explanation": "층층이 쌓는 방식"
 },
 {
  "id": "C-064",
  "type": "choice",
  "question": "AI 모델 학습 전 결측치와 이상치를 처리하는 단계는?",
  "options": [
   "모델 배포",
   "추론",
   "데이터 전처리",
   "성능 공시"
  ],
  "answer": 3,
  "explanation": "학습 전 데이터 정제"
 },
 {
  "id": "C-065",
  "type": "choice",
  "question": "수준확인의 지표를 옳게 짝지은 것은?",
  "options": [
   "대표지표: 기업제조혁신역량, 보조지표: 구축시스템 스마트화",
   "대표지표: 매출액, 보조지표: 종업원 수",
   "대표지표: 구축시스템 스마트화, 보조지표: 기업제조혁신역량",
   "대표지표: 특허 수, 보조지표: 수출액"
  ],
  "answer": 3,
  "explanation": "구축시스템이 대표, 혁신역량이 보조"
 },
 {
  "id": "C-066",
  "type": "choice",
  "question": "기업제조혁신역량 수준의 구분으로 옳은 것은?",
  "options": [
   "Level 1~5의 5단계",
   "기초~고도의 4단계",
   "A~C의 3단계",
   "1~10의 10단계"
  ],
  "answer": 1,
  "explanation": "Level 1~5"
 },
 {
  "id": "C-067",
  "type": "choice",
  "question": "기업제조혁신역량 수준이 주로 평가하는 내용은?",
  "options": [
   "공장 부지 면적",
   "대표자 학력",
   "주식 시장 가치",
   "경영, 제조, 프로세스 등 제조혁신 역량"
  ],
  "answer": 4,
  "explanation": "경영, 제조, 프로세스 등 역량"
 },
 {
  "id": "C-068",
  "type": "choice",
  "question": "수준확인 추진 절차의 순서로 옳은 것은?",
  "options": [
   "신청 → 심의 → 현장심사 → 요건검토 → 확인서 발급",
   "신청·접수 → 요건 검토 → 심사원 배정 → 사전 검토 및 현장심사 → 보고서 검토 및 심의요청 → 수준확인 심의 → 확인서 발급",
   "심사원 배정 → 공고 → 신청 → 확인서 발급 → 심의",
   "현장심사 → 신청 → 심사원 배정 → 심의 → 요건 검토"
  ],
  "answer": 2,
  "explanation": "2026 공고의 추진 절차"
 },
 {
  "id": "C-069",
  "type": "choice",
  "question": "신청 요건 검토와 심사원 배정을 수행하는 기관은?",
  "options": [
   "확인기관",
   "교육·심의기관",
   "총괄기관",
   "공급기업"
  ],
  "answer": 1,
  "explanation": "확인기관의 업무"
 },
 {
  "id": "C-070",
  "type": "choice",
  "question": "수준확인 심의위원회를 운영하는 기관은?",
  "options": [
   "도입기업",
   "총괄기관",
   "교육·심의기관",
   "감리기관"
  ],
  "answer": 3,
  "explanation": "교육·심의기관이 운영"
 },
 {
  "id": "C-071",
  "type": "choice",
  "question": "심사원 양성 및 보수 교육 프로그램을 운영하는 기관은?",
  "options": [
   "지원기업",
   "확인기관",
   "원가계산기관",
   "교육·심의기관"
  ],
  "answer": 4,
  "explanation": "교육·심의기관의 업무"
 },
 {
  "id": "C-072",
  "type": "choice",
  "question": "확인기관이 한 지원기업에 배정할 수 있는 심사원 수는?",
  "options": [
   "1명만",
   "1~2명",
   "3~4명",
   "5명 이상"
  ],
  "answer": 2,
  "explanation": "1~2명 배정 가능"
 },
 {
  "id": "C-073",
  "type": "choice",
  "question": "확인기관의 심사원 배정 기한은 선정 통보일로부터 며칠 이내인가?",
  "options": [
   "1일",
   "2일",
   "3일",
   "7일"
  ],
  "answer": 3,
  "explanation": "선정 통보일로부터 3일 이내"
 },
 {
  "id": "C-074",
  "type": "choice",
  "question": "심사원은 수준확인 심사일로부터 며칠 내에 보고서와 평가표를 제출해야 하는가?",
  "options": [
   "3일",
   "5일",
   "7일",
   "14일"
  ],
  "answer": 4,
  "explanation": "심사일로부터 14일 내"
 },
 {
  "id": "C-075",
  "type": "choice",
  "question": "심사원의 수행 제한으로 옳은 것은?",
  "options": [
   "동일한 날에 2개 이상의 지원기업을 수준확인할 수 없다",
   "하루 최대 3개 기업까지 가능하다",
   "같은 지역이면 횟수 제한이 없다",
   "2인 심사 시 하루 4개 기업까지 가능하다"
  ],
  "answer": 1,
  "explanation": "같은 날 2개 이상 불가"
 },
 {
  "id": "C-076",
  "type": "choice",
  "question": "지원기업의 사업신청일로부터 심사가 완료되어야 하는 기간은?",
  "options": [
   "14일 이내",
   "30일 이내",
   "60일 이내",
   "90일 이내"
  ],
  "answer": 2,
  "explanation": "신청일로부터 30일 이내"
 },
 {
  "id": "C-077",
  "type": "choice",
  "question": "심의위원회 구성 기준으로 옳은 것은?",
  "options": [
   "최소 2인, 외부위원 없어도 됨",
   "최소 3인, 외부위원 1인 이상",
   "최소 5인, 외부위원 2인 이상",
   "최소 10인, 전원 외부위원"
  ],
  "answer": 3,
  "explanation": "최소 5인, 외부위원 2인 이상"
 },
 {
  "id": "C-078",
  "type": "choice",
  "question": "3번 이상 보완 요청을 받은 지원과제의 처리로 옳은 것은?",
  "options": [
   "자동으로 최고 수준을 부여한다",
   "4차 보완을 무기한 허용한다",
   "신청기업이 직접 수준을 결정한다",
   "심의를 종료하고 심사원을 새로 배정해 수준확인을 다시 수행한다"
  ],
  "answer": 4,
  "explanation": "심의 종료 후 새 심사원이 재수행"
 },
 {
  "id": "C-079",
  "type": "choice",
  "question": "수준확인 평가모델의 기본 구성으로 알려진 것은?",
  "options": [
   "3영역, 5범주, 20항목, 500점",
   "4영역, 10범주, 44항목, 1,000점",
   "5영역, 12범주, 60항목, 1,200점",
   "6영역, 15범주, 100항목, 2,000점"
  ],
  "answer": 2,
  "explanation": "4개 영역, 10개 범주, 44개 항목"
 },
 {
  "id": "C-080",
  "type": "choice",
  "question": "KS X 9001-3 기반 모델에서 배점이 가장 큰 영역은?",
  "options": [
   "추진전략",
   "프로세스",
   "정보시스템과 자동화",
   "성과"
  ],
  "answer": 3,
  "explanation": "정보시스템과 자동화 400점"
 },
 {
  "id": "C-081",
  "type": "choice",
  "question": "프로세스 영역의 배점으로 알려진 것은?",
  "options": [
   "380점",
   "100점",
   "120점",
   "500점"
  ],
  "answer": 1,
  "explanation": "프로세스 6개 모듈 380점"
 },
 {
  "id": "C-082",
  "type": "choice",
  "question": "‘리더십과 전략’ 범주의 평가항목이 아닌 것은?",
  "options": [
   "리더십",
   "조직 및 역량관리",
   "성과지표(KPI) 관리",
   "설비 예비품 관리"
  ],
  "answer": 4,
  "explanation": "설비관리 범주의 내용"
 },
 {
  "id": "C-083",
  "type": "choice",
  "question": "성과 영역의 배점으로 알려진 것은?",
  "options": [
   "60점",
   "120점",
   "200점",
   "400점"
  ],
  "answer": 2,
  "explanation": "성과 120점"
 },
 {
  "id": "C-084",
  "type": "choice",
  "question": "성과 영역의 평가 대상이 아닌 것은?",
  "options": [
   "생산성",
   "납기",
   "주가수익률",
   "안전"
  ],
  "answer": 3,
  "explanation": "생산성, 품질, 원가, 납기, 안전, 환경"
 },
 {
  "id": "C-085",
  "type": "choice",
  "question": "2026년 기준 Level 3의 점수 구간은?",
  "options": [
   "750~849점",
   "550~649점",
   "650~749점",
   "850~949점"
  ],
  "answer": 1,
  "explanation": "750~849점"
 },
 {
  "id": "C-086",
  "type": "choice",
  "question": "기업제조혁신역량 점수가 735점인 기업의 세부 등급은?",
  "options": [
   "Level 1+",
   "Level 2-",
   "Level 2",
   "Level 2+"
  ],
  "answer": 4,
  "explanation": "Level 2+는 720~750점"
 },
 {
  "id": "C-087",
  "type": "choice",
  "question": "5점 척도 점수 2.0에 해당하는 세부 등급은?",
  "options": [
   "Level 1",
   "Level 2",
   "Level 2+",
   "Level 3"
  ],
  "answer": 2,
  "explanation": "Level 2는 1.8~2.2"
 },
 {
  "id": "C-088",
  "type": "choice",
  "question": "Level 4의 특성으로 옳은 것은?",
  "options": [
   "식별 및 점검",
   "측정 및 확인",
   "최적화 및 통합",
   "미인식 및 미적용"
  ],
  "answer": 3,
  "explanation": "Optimized & Integrated"
 },
 {
  "id": "C-089",
  "type": "choice",
  "question": "Level 1의 조건으로 옳은 것은?",
  "options": [
   "부분적 표준화 및 실적정보 관리",
   "생산정보 실시간 모니터링",
   "수집된 정보를 분석해 제어",
   "제어와 최적화까지 자율 운영"
  ],
  "answer": 1,
  "explanation": "Identified & Checked"
 },
 {
  "id": "C-090",
  "type": "choice",
  "question": "550점 미만인 기업의 등급은?",
  "options": [
   "Level 3",
   "Level 2",
   "Level 1",
   "Level 0"
  ],
  "answer": 4,
  "explanation": "미인식 및 ICT 미적용"
 },
 {
  "id": "C-091",
  "type": "choice",
  "question": "구축시스템 스마트화 수준 정의표에서 ‘중간1’의 현장자동화 특성은?",
  "options": [
   "수작업",
   "실적집계 자동화",
   "설비데이터 자동집계",
   "설비제어 자동화"
  ],
  "answer": 3,
  "explanation": "기초는 실적집계, 중간2는 설비제어 자동화"
 },
 {
  "id": "C-092",
  "type": "choice",
  "question": "2026년부터 적용된 개선 평가지표의 내용으로 옳은 것은?",
  "options": [
   "모든 평가 항목에서 정보시스템 영역을 삭제",
   "중간1 단계부터 AI 기능 평가 도입, 안전과 에너지 항목 추가",
   "기초 단계만 평가하도록 축소",
   "대기업만 평가 대상으로 변경"
  ],
  "answer": 2,
  "explanation": "2026년 개선 평가지표"
 },
 {
  "id": "C-093",
  "type": "choice",
  "question": "심사결과보고서로 지원기업에 제공하는 내용으로 가장 옳은 것은?",
  "options": [
   "대표자의 개인 신용 정보",
   "경쟁사의 영업비밀",
   "정부지원금 지급 확약",
   "강점, 약점, 개선점, 고도화 로드맵"
  ],
  "answer": 4,
  "explanation": "심사결과보고서의 구성"
 },
 {
  "id": "C-094",
  "type": "choice",
  "question": "심사원이 수준확인 후 제출하는 서류로 옳은 것은?",
  "options": [
   "심사보고서, 구축시스템 스마트화 수준 평가표, 기업제조혁신역량 수준 평가표",
   "세금계산서, 재무제표",
   "공급기업 제안서, 원가계산서",
   "기술임치 계약서, 인수인계서"
  ],
  "answer": 1,
  "explanation": "보고서와 두 수준 평가표"
 },
 {
  "id": "C-095",
  "type": "choice",
  "question": "심사보고서 보완이 필요할 때의 제출 기한은?",
  "options": [
   "통보일로부터 3일, 연장 불가",
   "통보일로부터 5일, 연장 3일",
   "통보일로부터 7일, 필요 시 7일 연장",
   "통보일로부터 30일, 연장 30일"
  ],
  "answer": 3,
  "explanation": "7일 이내, 7일 연장 가능"
 },
 {
  "id": "C-096",
  "type": "choice",
  "question": "지원과제에 대해 3회 이상 보완 요청을 받은 심사원의 조치는?",
  "options": [
   "수당 2배 지급",
   "심사 자격 박탈 및 심사원 Pool 제외",
   "다음 해 우선 배정",
   "조치 없음"
  ],
  "answer": 2,
  "explanation": "자격 박탈 및 Pool 제외. 보수 교육 이수로 회복 가능"
 },
 {
  "id": "C-097",
  "type": "choice",
  "question": "심사원이 스스로 회피해야 하는 친족 범위로 옳은 것은?",
  "options": [
   "2촌 이내 혈족만",
   "4촌 이내 혈족, 2촌 이내 인척",
   "6촌 이내 혈족만",
   "8촌 이내 혈족, 4촌 이내 인척, 배우자"
  ],
  "answer": 4,
  "explanation": "민법 제777조의 친족 범위"
 },
 {
  "id": "C-098",
  "type": "choice",
  "question": "지원기업의 수준등급 이의신청 기준으로 옳은 것은?",
  "options": [
   "확인서 발급일로부터 10일 이내, 1회",
   "발급일로부터 30일 이내, 3회",
   "유효기간 내 언제든 무제한",
   "심사 당일 구두로만 가능"
  ],
  "answer": 1,
  "explanation": "10일 이내, 1회"
 },
 {
  "id": "C-099",
  "type": "choice",
  "question": "수준확인서의 유효기간과 인센티브 제공 기간으로 옳은 것은?",
  "options": [
   "1년, 영구",
   "2년, 5년",
   "3년, 유효기간 내",
   "5년, 10년"
  ],
  "answer": 3,
  "explanation": "3년이며 인센티브도 유효기간 내"
 },
 {
  "id": "C-100",
  "type": "choice",
  "question": "심사보고서 작성 태도로 부적절한 것은?",
  "options": [
   "현장 확인 사실과 증빙을 근거로 작성한다",
   "기업의 자가진단 결과를 현장 확인 없이 그대로 옮긴다",
   "개선 과제를 기업 수준에 맞게 제시한다",
   "기업 정보를 비밀로 유지한다"
  ],
  "answer": 2,
  "explanation": "현장 확인과 증빙이 필요"
 },
 {
  "id": "S-001",
  "type": "short",
  "question": "제조기업의 스마트화 수준을 합의된 절차와 기준에 따라 공신력 있는 기관이 확인·검증하는 제도의 이름은?",
  "answer": "스마트공장 수준확인(제도)",
  "accepted": [
   "스마트공장 수준확인(제도)",
   "스마트공장 수준확인 제도",
   "스마트공장 수준확인제도",
   "스마트공장 수준확인",
   "수준확인 제도",
   "수준확인제도",
   "수준확인"
  ],
  "explanation": ""
 },
 {
  "id": "S-002",
  "type": "short",
  "question": "수준확인서의 유효기간은 발급일로부터 몇 년인가?",
  "answer": "3년",
  "accepted": [
   "3년",
   "3"
  ],
  "explanation": ""
 },
 {
  "id": "S-003",
  "type": "short",
  "question": "주요 시스템과 ICT 자동화기술 수준에 따라 4단계로 구분하는 대표지표의 이름은?",
  "answer": "구축시스템 스마트화 수준",
  "accepted": [
   "구축시스템 스마트화 수준",
   "구축시스템 스마트화"
  ],
  "explanation": ""
 },
 {
  "id": "S-004",
  "type": "short",
  "question": "제조혁신 역량 수준을 Level 1~5로 구분하는 보조지표의 이름은?",
  "answer": "기업제조혁신역량 수준",
  "accepted": [
   "기업제조혁신역량 수준",
   "기업제조혁신역량"
  ],
  "explanation": ""
 },
 {
  "id": "S-005",
  "type": "short",
  "question": "심의위원회를 운영하고 심사원 교육을 담당하는 기관의 명칭은?",
  "answer": "교육·심의기관",
  "accepted": [
   "교육·심의기관",
   "교육심의기관",
   "교육 심의기관",
   "교육/심의기관",
   "교육·심의 기관"
  ],
  "explanation": ""
 },
 {
  "id": "S-006",
  "type": "short",
  "question": "신청 요건을 검토하고 심사원을 배정하는 기관의 명칭은?",
  "answer": "확인기관",
  "accepted": [
   "확인기관"
  ],
  "explanation": ""
 },
 {
  "id": "S-007",
  "type": "short",
  "question": "심사원은 심사일로부터 며칠 내에 심사보고서를 제출해야 하는가?",
  "answer": "14일",
  "accepted": [
   "14일",
   "14"
  ],
  "explanation": ""
 },
 {
  "id": "S-008",
  "type": "short",
  "question": "심의위원회의 최소 구성 인원은 몇 명인가?",
  "answer": "5명(5인)",
  "accepted": [
   "5명(5인)",
   "5명",
   "5인",
   "5"
  ],
  "explanation": ""
 },
 {
  "id": "S-009",
  "type": "short",
  "question": "수준확인 평가모델의 총 배점은 몇 점인가?",
  "answer": "1,000점",
  "accepted": [
   "1,000점",
   "1000점",
   "1000",
   "1,000"
  ],
  "explanation": ""
 },
 {
  "id": "S-010",
  "type": "short",
  "question": "KS X 9001-3의 6개 프로세스 중 제품개발, 생산계획, 공정관리, 품질관리, 물류관리를 제외한 나머지 하나는?",
  "answer": "설비관리",
  "accepted": [
   "설비관리"
  ],
  "explanation": ""
 },
 {
  "id": "S-011",
  "type": "short",
  "question": "기업제조혁신역량 Level 4의 특성을 한글로 쓰시오.",
  "answer": "최적화 및 통합",
  "accepted": [
   "최적화 및 통합",
   "최적화와 통합",
   "최적화·통합"
  ],
  "explanation": ""
 },
 {
  "id": "S-012",
  "type": "short",
  "question": "기업제조혁신역량 Level 1의 최저 점수는?",
  "answer": "550점",
  "accepted": [
   "550점",
   "550"
  ],
  "explanation": ""
 },
 {
  "id": "S-013",
  "type": "short",
  "question": "4M+1E에서 E가 뜻하는 영어 단어는?",
  "answer": "Environment",
  "accepted": [
   "Environment",
   "environment"
  ],
  "explanation": ""
 },
 {
  "id": "S-014",
  "type": "short",
  "question": "BOM의 우리말 명칭은?",
  "answer": "자재명세서",
  "accepted": [
   "자재명세서",
   "자재 명세서"
  ],
  "explanation": ""
 },
 {
  "id": "S-015",
  "type": "short",
  "question": "MES의 우리말 명칭은?",
  "answer": "제조실행시스템",
  "accepted": [
   "제조실행시스템",
   "제조 실행 시스템"
  ],
  "explanation": ""
 },
 {
  "id": "S-016",
  "type": "short",
  "question": "OEE의 우리말 명칭은?",
  "answer": "설비종합효율",
  "accepted": [
   "설비종합효율",
   "설비 종합 효율"
  ],
  "explanation": ""
 },
 {
  "id": "S-017",
  "type": "short",
  "question": "생산시점관리를 뜻하는 영문 약어는?",
  "answer": "POP",
  "accepted": [
   "POP",
   "pop"
  ],
  "explanation": ""
 },
 {
  "id": "S-018",
  "type": "short",
  "question": "현실의 설비·공정을 가상공간에 복제해 연동·시뮬레이션하는 기술은?",
  "answer": "디지털 트윈",
  "accepted": [
   "디지털 트윈",
   "디지털트윈",
   "Digital Twin"
  ],
  "explanation": ""
 },
 {
  "id": "S-019",
  "type": "short",
  "question": "설비 상태 데이터로 고장 시점을 예측해 정비하는 보전 방식은?",
  "answer": "예지보전",
  "accepted": [
   "예지보전",
   "예지 보전",
   "예측보전"
  ],
  "explanation": ""
 },
 {
  "id": "S-020",
  "type": "short",
  "question": "2026년 개선 지표에서 중간1 단계부터 평가가 도입된 기능은?",
  "answer": "AI(인공지능) 기능",
  "accepted": [
   "AI(인공지능) 기능",
   "AI",
   "인공지능",
   "AI 기능",
   "인공지능 기능"
  ],
  "explanation": ""
 }
];
