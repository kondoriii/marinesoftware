/* 스마트공장 수준확인 심사원 모의고사 */
(function () {
  'use strict';

  var EXAM_SIZE = 25;
  var PASS_LINE = 18;   // 18문제 이상 정답이면 pass
  var EXAM_MS = 60 * 60 * 1000;   // 제한 시간 60분
  var WARN_MS = 5 * 60 * 1000;    // 남은 시간 5분 이하면 빨간색
  var RECORD_KEY = 'smartExam.records';
  var SESSION_KEY = 'smartExam.session';   // 풀던 모의고사 (이어 풀기용)
  var WRONG_KEY = 'smartExam.wrong';       // 오답노트 (틀린 문제 id 목록)
  var SEEN_KEY = 'smartExam.seen';         // 모의고사에서 푼 문제 id 목록 (안 푼 문제 우선 출제용)
  var MARKS = ['①', '②', '③', '④'];
  var ALL = window.QUESTIONS || [];

  function $(id) { return document.getElementById(id); }
  var el = {
    startScreen: $('startScreen'),
    quizScreen: $('quizScreen'),
    recordScreen: $('recordScreen'),
    btnStart: $('btnStart'),
    btnRecords: $('btnRecords'),
    btnWrong: $('btnWrong'),
    btnWrong2: $('btnWrong2'),
    unseenInfo: $('unseenInfo'),
    progress: $('progress'),
    timer: $('timer'),
    btnCheck: $('btnCheck'),
    btnNext: $('btnNext'),
    btnEnd: $('btnEnd'),
    qArea: $('questionArea'),
    aArea: $('answerArea'),
    recordBody: $('recordBody'),
    btnNewExam: $('btnNewExam'),
    modal: $('modal'),
    modalMsg: $('modalMsg'),
    modalOk: $('modalOk'),
    modalCancel: $('modalCancel')
  };

  var exam = [];          // 이번 회차 문제 25개
  var answers = [];       // 문제별 응답 (객관식: 1~4, 단답형: 입력 글자)
  var index = 0;          // 현재 문제 위치
  var finished = false;   // 채점·저장이 끝났는지 (한 회차에 한 번만 저장)
  var result = 0;         // 채점 결과 (맞춘 개수)
  var mode = 'exam';      // 'exam': 모의고사, 'wrong': 오답노트 풀기
  var deadline = 0;       // 모의고사 종료 시각 (ms). 실제 시계 기준이라 새로고침·종료해도 시간이 흐름
  var timerId = null;

  // 배열을 섞은 복사본 반환 (Fisher-Yates)
  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  // 화면에 넣을 글자의 특수문자 처리
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // ===== 채점 =====
  // 단답형 비교용: 공백 제거, 영문 대소문자 무시
  function normalize(s) {
    return String(s == null ? '' : s).replace(/\s+/g, '').toLowerCase();
  }
  function isAnswered(q, a) {
    if (q.type === 'choice') return a >= 1 && a <= 4;
    return normalize(a) !== '';   // 공백만 입력하면 미응답
  }
  function isCorrect(q, a) {
    if (!isAnswered(q, a)) return false;   // 안 푼 문제는 오답
    if (q.type === 'choice') return a === q.answer;
    var user = normalize(a);
    return (q.accepted || []).some(function (x) { return normalize(x) === user; });
  }
  function countCorrect(questions, userAnswers) {
    var n = 0;
    questions.forEach(function (q, i) { if (isCorrect(q, userAnswers[i])) n++; });
    return n;
  }
  function isPass(correct) { return correct >= PASS_LINE; }

  // ===== 기록 (localStorage) =====
  function loadRecords() {
    try {
      var list = JSON.parse(localStorage.getItem(RECORD_KEY));
      return Array.isArray(list) ? list : [];
    } catch (e) {
      return [];
    }
  }
  function saveRecord(correct) {
    var list = loadRecords();
    list.push({
      date: today(),
      round: list.length + 1,   // 회차 = 저장된 기록 수 + 1
      correct: correct,
      total: exam.length,
      pass: isPass(correct)
    });
    try { localStorage.setItem(RECORD_KEY, JSON.stringify(list)); } catch (e) { /* 저장 불가 환경 */ }
  }
  function today() {
    var d = new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }

  // ===== 오답노트 =====
  function loadWrong() {
    var list;
    try { list = JSON.parse(localStorage.getItem(WRONG_KEY)); } catch (e) { list = null; }
    if (!Array.isArray(list)) return [];
    var valid = {};
    ALL.forEach(function (q) { valid[q.id] = true; });
    return list.filter(function (id) { return valid[id]; });
  }
  function saveWrong(list) {
    try { localStorage.setItem(WRONG_KEY, JSON.stringify(list)); } catch (e) { /* 저장 불가 환경 */ }
  }
  function addWrong(id) {
    var list = loadWrong();
    if (list.indexOf(id) < 0) { list.push(id); saveWrong(list); }
  }
  function removeWrong(id) {
    var list = loadWrong();
    var i = list.indexOf(id);
    if (i >= 0) { list.splice(i, 1); saveWrong(list); }
  }
  // 모의고사 채점 때: 답했는데 틀린 문제는 추가, 맞힌 문제는 오답노트에서 뺌
  // (도중 종료로 안 푼 문제는 넣지 않음)
  function updateWrongFromExam() {
    exam.forEach(function (q, i) {
      if (!isAnswered(q, answers[i])) return;
      if (isCorrect(q, answers[i])) removeWrong(q.id);
      else addWrong(q.id);
    });
  }

  // ===== 안 푼 문제 우선 출제 =====
  function loadSeen() {
    var list;
    try { list = JSON.parse(localStorage.getItem(SEEN_KEY)); } catch (e) { list = null; }
    if (!Array.isArray(list)) return [];
    var valid = {};
    ALL.forEach(function (q) { valid[q.id] = true; });
    return list.filter(function (id) { return valid[id]; });
  }
  function saveSeen(list) {
    try { localStorage.setItem(SEEN_KEY, JSON.stringify(list)); } catch (e) { /* 저장 불가 환경 */ }
  }
  // 모의고사 채점 때 답한 문제를 '푼 문제'로 기록 (도중 종료로 안 푼 문제는 제외)
  function markSeen() {
    var list = loadSeen();
    var has = {};
    list.forEach(function (id) { has[id] = true; });
    exam.forEach(function (q, i) {
      if (isAnswered(q, answers[i]) && !has[q.id]) { list.push(q.id); has[q.id] = true; }
    });
    saveSeen(list);
  }
  // 안 푼 문제에서 먼저 뽑고, 모자라면 푼 문제에서 채움 (모두 풀었으면 처음부터 다시)
  function pickExam() {
    var seen = loadSeen();
    if (seen.length >= ALL.length) {
      seen = [];
      saveSeen(seen);
    }
    var has = {};
    seen.forEach(function (id) { has[id] = true; });
    var unseen = shuffle(ALL.filter(function (q) { return !has[q.id]; }));
    var done = shuffle(ALL.filter(function (q) { return has[q.id]; }));
    return unseen.concat(done).slice(0, EXAM_SIZE);   // 중복 없이 25문제
  }

  // ===== 이어 풀기 (풀던 문제·답·위치를 저장) =====
  function saveSession() {
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify({
        mode: mode,
        deadline: deadline,
        ids: exam.map(function (q) { return q.id; }),
        answers: answers,
        index: index
      }));
    } catch (e) { /* 저장 불가 환경 */ }
  }
  function clearSession() {
    try { localStorage.removeItem(SESSION_KEY); } catch (e) { /* 무시 */ }
  }
  // 저장된 풀이가 있으면 그 문제부터 다시 보여 줌
  function resumeSession() {
    var s;
    try { s = JSON.parse(localStorage.getItem(SESSION_KEY)); } catch (e) { s = null; }
    if (!s || !Array.isArray(s.ids) || !Array.isArray(s.answers) || s.ids.length !== s.answers.length) return false;
    var byId = {};
    ALL.forEach(function (q) { byId[q.id] = q; });
    var list = s.ids.map(function (id) { return byId[id]; });
    if (!list.length || list.some(function (q) { return !q; }) ||
        !(s.index >= 0 && s.index < list.length)) {
      clearSession();   // 문제 데이터가 바뀌어 맞지 않으면 버림
      return false;
    }
    exam = list;
    answers = s.answers;
    index = s.index;
    mode = s.mode === 'wrong' ? 'wrong' : 'exam';
    finished = false;
    result = 0;
    showScreen(el.quizScreen);
    renderQuestion();
    if (mode === 'exam') {
      deadline = s.deadline > 0 ? s.deadline : Date.now() + EXAM_MS;
      startTimer();   // 꺼져 있는 동안 시간이 다 지났으면 바로 시간 종료 처리
    } else {
      stopTimer();
    }
    return true;
  }

  // ===== 60분 타이머 (모의고사에만 적용) =====
  function formatTime(ms) {
    var sec = Math.max(0, Math.ceil(ms / 1000));
    var m = Math.floor(sec / 60), s = sec % 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  function startTimer() {
    clearInterval(timerId);
    el.timer.classList.remove('hidden');
    tick();
    if (!finished) timerId = setInterval(tick, 1000);
  }
  function stopTimer() {
    clearInterval(timerId);
    timerId = null;
    if (mode !== 'exam') el.timer.classList.add('hidden');
  }
  function tick() {
    if (mode !== 'exam' || finished) { stopTimer(); return; }
    var left = deadline - Date.now();
    el.timer.textContent = '남은 시간 ' + formatTime(left);
    el.timer.classList.toggle('warn', left <= WARN_MS);
    if (left <= 0) timeUp();
  }
  // 시간 종료: 지금까지의 답으로 채점·저장 후 기록 리스트로
  function timeUp() {
    stopTimer();
    var correct = finishExam();
    var pass = isPass(correct);
    showModal('시간이 종료되었습니다.<br>' + exam.length + '문제 중 ' + correct + '문제 정답' +
      '<span class="modal-result ' + (pass ? 'pass' : 'fail') + '">' + (pass ? 'pass' : 'fail') + '</span>',
      { onOk: showRecords });
  }

  // 채점하고 한 번만 저장 (채점 뒤에는 저장된 결과를 그대로 사용)
  function finishExam() {
    if (!finished) {
      finished = true;
      stopTimer();
      result = countCorrect(exam, answers);
      saveRecord(result);
      updateWrongFromExam();
      markSeen();
      clearSession();   // 끝난 회차는 이어 풀기 대상 아님
    }
    return result;
  }

  // ===== 알림창 =====
  var modalOnOk = null;
  function showModal(html, opts) {
    opts = opts || {};
    modalOnOk = opts.onOk || null;
    el.modalMsg.innerHTML = html;
    el.modalCancel.classList.toggle('hidden', !opts.cancel);
    el.modal.classList.remove('hidden');
    el.modalOk.focus();
  }
  function closeModal() {
    el.modal.classList.add('hidden');
  }
  el.modalOk.addEventListener('click', function () {
    var fn = modalOnOk;
    modalOnOk = null;
    closeModal();
    if (fn) fn();
  });
  el.modalCancel.addEventListener('click', function () {
    modalOnOk = null;
    closeModal();
  });

  // ===== 화면 =====
  function showScreen(screen) {
    [el.startScreen, el.quizScreen, el.recordScreen].forEach(function (s) {
      s.classList.toggle('hidden', s !== screen);
    });
  }

  // [오답노트 풀기] 버튼에 문제 수 표시
  function refreshWrongButtons() {
    var label = '오답노트 풀기 (' + loadWrong().length + '문제)';
    el.btnWrong.textContent = label;
    el.btnWrong2.textContent = label;
  }
  function showStart() {
    refreshWrongButtons();
    var seen = loadSeen().length;
    el.unseenInfo.textContent = '안 푼 문제 ' + (ALL.length - seen) + ' / ' + ALL.length;
    showScreen(el.startScreen);
  }

  function startExam() {
    mode = 'exam';
    exam = pickExam();   // 안 푼 문제 우선, 중복 없이 25문제
    answers = exam.map(function () { return null; });
    index = 0;
    finished = false;
    result = 0;
    deadline = Date.now() + EXAM_MS;
    showScreen(el.quizScreen);
    renderQuestion();
    saveSession();
    startTimer();
  }

  // 오답노트의 문제를 모두 섞어서 풀기
  function startWrong() {
    var byId = {};
    ALL.forEach(function (q) { byId[q.id] = q; });
    var ids = loadWrong();
    if (!ids.length) {
      showModal('오답노트에 문제가 없습니다.<br>모의고사에서 틀린 문제가 여기에 모입니다.');
      return;
    }
    mode = 'wrong';
    deadline = 0;
    stopTimer();   // 오답노트 풀기는 시간 제한 없음
    exam = shuffle(ids).map(function (id) { return byId[id]; });
    answers = exam.map(function () { return null; });
    index = 0;
    finished = false;
    result = 0;
    showScreen(el.quizScreen);
    renderQuestion();
    saveSession();
  }

  function renderQuestion() {
    var q = exam[index];
    el.progress.textContent = (mode === 'wrong' ? '오답 ' : '') + (index + 1) + ' / ' + exam.length;
    el.aArea.innerHTML = '';

    var html = '<p class="question-id">' + esc(q.id) + (q.type === 'short' ? ' · 단답형' : '') + '</p>' +
      '<p class="question-text">' + esc(q.question) + '</p>';

    if (q.type === 'choice') {
      q.options.forEach(function (opt, i) {
        html += '<label class="option">' +
          '<input type="radio" name="choice" value="' + (i + 1) + '">' +
          '<span>' + MARKS[i] + ' ' + esc(opt) + '</span>' +
          '</label>';
      });
    } else {
      html += '<input type="text" class="short-input" placeholder="답을 입력하세요" autocomplete="off" autocapitalize="off" spellcheck="false">';
    }
    el.qArea.innerHTML = html;
    el.qArea.scrollTop = 0;

    // 응답 저장 + 선택한 보기 강조 (이어 풀기 때는 저장된 답을 다시 표시)
    var radios = el.qArea.querySelectorAll('input[type="radio"]');
    function markSelected() {
      Array.prototype.forEach.call(radios, function (x) {
        x.parentNode.classList.toggle('selected', x.checked);
      });
    }
    Array.prototype.forEach.call(radios, function (r) {
      if (Number(r.value) === answers[index]) r.checked = true;
      r.addEventListener('change', function () {
        answers[index] = Number(r.value);
        markSelected();
        if (!finished) saveSession();
      });
    });
    markSelected();
    var input = el.qArea.querySelector('.short-input');
    if (input) {
      if (typeof answers[index] === 'string') input.value = answers[index];
      input.addEventListener('input', function () {
        answers[index] = input.value;
        if (!finished) saveSession();
      });
    }
  }

  function showAnswer() {
    var q = exam[index];
    var answerText = q.type === 'choice'
      ? MARKS[q.answer - 1] + ' ' + q.options[q.answer - 1]
      : q.answer;
    var html = '<p class="answer-title">정답: ' + esc(answerText) + '</p>';
    if (q.explanation) {
      html += '<p class="answer-exp">해설: ' + esc(q.explanation) + '</p>';
    }
    el.aArea.innerHTML = html;
    el.aArea.scrollTop = 0;
  }

  function goNext() {
    if (!isAnswered(exam[index], answers[index])) {
      showModal('답을 하지 않으면 모의고사가 진행되지 않아요');
      return;
    }
    if (mode === 'wrong') {
      wrongNext();
      return;
    }
    if (index < exam.length - 1) {
      index++;
      renderQuestion();
      saveSession();
      return;
    }
    // 25번째 문제: 채점 (기록은 처음 한 번만 저장)
    var correct = finishExam();
    var pass = isPass(correct);
    showModal(exam.length + '문제 중 ' + correct + '문제 정답' +
      '<span class="modal-result ' + (pass ? 'pass' : 'fail') + '">' + (pass ? 'pass' : 'fail') + '</span>');
  }

  // 오답노트 풀기에서 [Next]: 맞히면 오답노트에서 빼고, 틀리면 그대로 둠
  function wrongNext() {
    if (!finished) {
      var q = exam[index];
      if (isCorrect(q, answers[index])) removeWrong(q.id);
      if (index < exam.length - 1) {
        index++;
        renderQuestion();
        saveSession();
        return;
      }
      finished = true;
      result = countCorrect(exam, answers);
      clearSession();
    }
    showModal(exam.length + '문제 중 ' + result + '문제 정답<br>' +
      '오답노트에 남은 문제: ' + loadWrong().length + '문제', { onOk: showStart });
  }

  // [모의종료]
  function endExam() {
    if (mode === 'wrong') {   // 오답노트 풀기: 기록 저장 없이 시작 화면으로
      if (finished) { showStart(); return; }
      showModal('오답노트 풀기를 끝낼까요?<br>지금까지 맞힌 문제는 오답노트에서 빠집니다.', {
        cancel: true,
        onOk: function () { clearSession(); showStart(); }
      });
      return;
    }
    if (finished) {   // 25문제를 끝낸 뒤: 추가 저장 없이 이동
      showRecords();
      return;
    }
    showModal('지금 종료하면 안 푼 문제는 오답으로 기록됩니다', {
      cancel: true,
      onOk: function () {
        finishExam();
        showRecords();
      }
    });
  }

  // 기록 리스트 (최신 기록이 위)
  function showRecords() {
    var list = loadRecords().slice().reverse();
    if (!list.length) {
      el.recordBody.innerHTML = '<tr><td colspan="4" class="record-empty">아직 기록이 없습니다.</td></tr>';
    } else {
      el.recordBody.innerHTML = list.map(function (r) {
        var cls = r.pass ? 'pass' : 'fail';
        return '<tr>' +
          '<td>' + esc(r.date) + '</td>' +
          '<td>' + esc(r.round) + '</td>' +
          '<td>' + esc(r.correct) + '/' + esc(r.total) + '</td>' +
          '<td class="' + cls + '">' + cls + '</td>' +
          '</tr>';
      }).join('');
    }
    refreshWrongButtons();
    showScreen(el.recordScreen);
  }

  el.btnStart.addEventListener('click', startExam);
  el.btnRecords.addEventListener('click', showRecords);
  el.btnWrong.addEventListener('click', startWrong);
  el.btnWrong2.addEventListener('click', startWrong);
  el.btnNewExam.addEventListener('click', startExam);
  el.btnCheck.addEventListener('click', showAnswer);
  el.btnNext.addEventListener('click', goNext);
  el.btnEnd.addEventListener('click', endExam);

  // 새로고침·브라우저 재실행 시 풀던 문제부터 계속
  if (!resumeSession()) showStart();
})();
